﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 11/05/2010
//
// Last modified 11/05/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	//#region "Namespace delegates"
	//   public delegate void delLogMessage(string msg);
	//#endregion

	public class clsMessageSender
	{
		//*********************************************************************************************************
		// Provides a way for multiple classes to send messages to the log viewer
		//**********************************************************************************************************

		#region "Events"
			public static event delLogMessage LogMessageSent;
		#endregion

		#region "Methods"
			/// <summary>
			/// Raises the event to send a message to the log screen
			/// </summary>
			/// <param name="msg">Message string</param>
			public static void SendLogMessage(string direction, string msg)
			{
				if (LogMessageSent != null) LogMessageSent(direction, msg);
			}	// End sub
		#endregion
	}
}
