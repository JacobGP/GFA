﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 06/02/2010
//
// Last modified 06/02/2010
//						03/21/2011 (DAC) - Modified display scaling for demo purposes; Added plot reset via remote command or button
//
// Scrolling freq vs time chart code is based on sample code article "Display Dynamic or Real-Time Data" 
//		at http://zedgraph.org/wiki/index.php?title=Display_Dynamic_or_Real-Time_Data
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ZedGraph;
using System.IO;

namespace PHEV_01
{
	public partial class frmMain : Form
	{
		//*********************************************************************************************************
		// Main UI form for application. 
		//**********************************************************************************************************

		#region "Class variables"
			clsMainProgram m_MainProgram;
			System.Timers.Timer m_StartupDelayTimer;
			System.Timers.Timer m_RefreshTimer;
			bool m_SerialPortOpen = false;
			DateTime m_FreqGraphStartTime = DateTime.Now;
			DateTime m_PwrGraphStartTime = DateTime.Now;
			bool m_FreqGraphFirstPointReceived = false;
			bool m_PwrGraphFirstPointReceived = false;
			frmLogWindow m_LogWindow = null;
		#endregion

		#region "Delegates"
			delegate void delUpdateTextDisplay(string text);
			delegate void delUpdateProgressBar(int progressPercent);
			delegate void delUpdatePictureConnection(Image newImage);
			delegate void delUpdatePictureAuthentication(Image newImage);
			delegate void delUpdatePictureBinding(Image newImage);
			delegate void delUpdatePictureCharging(Image newImage);
			delegate void delUpdateStopChgButtonState(bool enabled);
			delegate void delUpdateContinueButtonState(bool enabled);
			delegate void delUpdateRadioButtonState(RadioButton radButton, bool enabled);
		#endregion

		#region "Constructors"
			public frmMain()
			{
				InitializeComponent();

				// Initialize main program class
				m_MainProgram = new clsMainProgram();

				// Display log window, if it's being used
				if (Properties.Settings.Default.ShowLogWindow)
				{
					m_LogWindow = new frmLogWindow();
					m_LogWindow.Show();
					this.Activate();
				}

				// Specify initial tab to display
				tabControl1.SelectedTab = tabFrequency;

				// Initialize the frequency graph
				InitFrequencyGraph();

				// Initialize the power graph
				InitPowerGraph();

				// Specify the serial port to be used
				string serPortName = SelectSerialPort();
				if (serPortName == "(None)")
				{
					m_MainProgram.SerialPortName = "";
					MessageBox.Show("No serial port selected. Program will not function");
				}
				else m_MainProgram.SerialPortName = serPortName;

				// Assign event handlers
				m_MainProgram.LogEnableChanged += new delDebugLogEnableChanged(OnLogEnableChanged);
				m_MainProgram.PauseEnableChanged += new delPauseEnableChanged(OnPauseEnableChanged);
				m_MainProgram.DateReceived += new delDateReceived(m_MainProgram_DateReceived);
				m_MainProgram.ChargeDataReceived += new delChargeDataReceived(m_MainProgram_ChargeDataReceived);
				m_MainProgram.ChargeConfigDataReceived += new delChargeConfigDataReceived(m_MainProgram_ChargeConfigDataReceived);
				m_MainProgram.StdMsgReceived +=new del2847MsgReceived(m_MainProgram_StdMsgReceived);
				m_MainProgram.ResetPlotsReceived += new delResetPlotsReceived(m_MainProgram_ResetPlotsReceived);

				// Setup a start delay to ensure form has fully loaded before interesting things start happening
				m_StartupDelayTimer = new System.Timers.Timer();
				m_StartupDelayTimer.Elapsed += new System.Timers.ElapsedEventHandler(m_StartupDelay_Elapsed);
				m_StartupDelayTimer.Interval = 500;
				m_StartupDelayTimer.Enabled = true;

				System.Threading.Thread.CurrentThread.Name = "UI_Thread";
			}
		#endregion

		#region "Methods"
			/// <summary>
			/// Sets serial port for use in communicating with GFC
			/// </summary>
			/// <returns>Port name if specified; otherwise "(None)"</returns>
			private string SelectSerialPort()
			{
				string tmpPortName = "(None)";

				string[] portList = System.IO.Ports.SerialPort.GetPortNames();
				if (portList.Length == 0)
				{
					tmpPortName = "(None)";
				}

				if (portList.Length == 1)
				{
					// Use the only port that's available
					tmpPortName = portList[0];
				}
				else
				{
					// Select the port name froma a list
					frmChoosePort portSelectForm = new frmChoosePort(portList);
					portSelectForm.ShowDialog();
					if (portSelectForm.DialogResult == System.Windows.Forms.DialogResult.OK)
					{
						tmpPortName = portSelectForm.SelectedPort;
					}
					else tmpPortName = "(None)";

					portSelectForm = null;
				}

				return tmpPortName;
			}	// End sub

			/// <summary>
			/// Creates an array of hours, beginning at midnight, in 15-minute increments
			/// </summary>
			/// <returns>Array of hours</returns>
			private double[] MakeHourArray()
			{
				double[] retArray = new double[96];
				double hour= 0.0;
				for (int indx = 0; indx < retArray.Length; indx++)
				{
					retArray[indx] = hour;
					hour = hour + 0.25;
				}

				return retArray;
			}	// End sub

			/// <summary>
			/// Initializes the frequency graph
			/// </summary>
			private void InitFrequencyGraph()
			{
				GraphPane freqPane = grphFreqChart.GraphPane;

				freqPane.Title.Text = "Power Line Frequency (Actual)";
				freqPane.Title.FontSpec.Size = 36;

				//freqPane.Legend.FontSpec.Size = 20;
				freqPane.Legend.IsVisible = false;

				// Manually control X-Axis range so graph scrolls continuously
				freqPane.XAxis.Title.Text = "Time Since Charge Started (Minutes)";
				freqPane.XAxis.Scale.Max = 15;
				freqPane.XAxis.Scale.MajorStep = 0.5;
				freqPane.XAxis.Scale.MinorStep = 0.25;

				// Setup Y axis
				freqPane.YAxis.Title.Text = "Power Line Frequency (Hz)";
				freqPane.YAxis.MajorTic.IsOpposite = false;
				freqPane.YAxis.MinorTic.IsOpposite = false;
				freqPane.YAxis.Scale.FormatAuto = false;
				freqPane.YAxis.Scale.Format = "00.000";

				// Add 2nd Y axis (Not used - just forces display width)
				freqPane.Y2Axis.Title.Text = "Power Line Frequency (Hz)";
				freqPane.Y2Axis.IsVisible = true;
				freqPane.Y2Axis.MajorTic.IsOpposite = false;
				freqPane.Y2Axis.MinorTic.IsOpposite = false;
				freqPane.Y2Axis.Scale.FormatAuto = false;
				freqPane.Y2Axis.Scale.Format = "00.000";

				// Save 900 points (approx. 15 minutes of data.
				RollingPointPairList freqList = new RollingPointPairList(900);
				RollingPointPairList aveFreqList = new RollingPointPairList(900);
				RollingPointPairList fakeFreqList = new RollingPointPairList(900);	// Fake for forcing Y2 axis rescale

				// Add initial curves with no data
				LineItem freqCurve = freqPane.AddCurve("Freq", freqList, Color.Black, SymbolType.None);
				freqCurve.Line.Width = 2;
				LineItem aveFreqCurve = freqPane.AddCurve("Ave Freq", aveFreqList, Color.Blue, SymbolType.Circle);
				aveFreqCurve.Line.Width = 1;
				aveFreqCurve.Line.Style = System.Drawing.Drawing2D.DashStyle.Solid;
				LineItem fakeFreqCurve = freqPane.AddCurve("Fake", fakeFreqList, Color.Black, SymbolType.None);	// Fake for forcing Y2 axis rescale
				fakeFreqCurve.IsY2Axis = true;
				fakeFreqCurve.IsVisible = false;

				// Scale the axes
				grphFreqChart.AxisChange();
			}	// End sub

			/// <summary>
			/// Initializes the Power/SOC graph
			/// </summary>
			private void InitPowerGraph()
			{
				GraphPane pwrPane = grphPwrChart.GraphPane;

				pwrPane.Title.Text = "State of Charge and Rate of Charge";
				pwrPane.Title.FontSpec.Size = 36;

//				pwrPane.Legend.FontSpec.Size = 20;
				pwrPane.Legend.IsVisible = false;

				// Manually control X-Axis range so graph scrolls continuously
				pwrPane.XAxis.Title.Text = "Time Since Charge Started (Minutes)";
				pwrPane.XAxis.Scale.Max = 15;
				pwrPane.XAxis.Scale.MajorStep = 0.5;
				pwrPane.XAxis.Scale.MinorStep = 0.25;

				// Setup Y axis
				pwrPane.YAxis.Title.Text = "State of Charge (%)";
				pwrPane.YAxis.MajorTic.IsOpposite = false;
				pwrPane.YAxis.MinorTic.IsOpposite = false;
				pwrPane.YAxis.Scale.FormatAuto = false;
				pwrPane.YAxis.Scale.Format = "#0.000";

				// Add 2nd Y axis
				pwrPane.Y2Axis.Title.Text = "Rate of Charge (kW)";
				pwrPane.Y2Axis.IsVisible = true;
				pwrPane.Y2Axis.Scale.FontSpec.FontColor = Color.Red;
				pwrPane.Y2Axis.Title.FontSpec.FontColor = Color.Red;
				pwrPane.Y2Axis.MajorTic.IsOpposite = false;
				pwrPane.Y2Axis.MinorTic.IsOpposite = false;
				pwrPane.Y2Axis.Scale.Min = 0;
				pwrPane.Y2Axis.Scale.FormatAuto = false;
				pwrPane.Y2Axis.Scale.Format = "#0.000";

				// Save 900 points (approx. 15 minutes of data.
				RollingPointPairList socList = new RollingPointPairList(900);
				RollingPointPairList rocList = new RollingPointPairList(900);

				// Add initial curves with no data
				LineItem socCurve = pwrPane.AddCurve("SOC", socList, Color.Black, SymbolType.Circle);
				socCurve.Line.Width = 1;
				LineItem rocCurve = pwrPane.AddCurve("ROC", rocList, Color.Red, SymbolType.None);
				rocCurve.Line.Width = 2;
				rocCurve.IsY2Axis = true;

				// Scale the axes
				grphPwrChart.AxisChange();
			}	// End sub

			/// <summary>
			/// Updates the frequency plot based on incoming data
			/// </summary>
			/// <param name="chargeData">Object containing one charge data point</param>
			private void UpdateFreqGraph(clsChargeData chargeData)
			{
				string msg;

				GraphPane freqPane = grphFreqChart.GraphPane;

				// If this is the first point in a new graph, then set appropriate class variables and clear point arrays
				if (!m_FreqGraphFirstPointReceived)
				{
					m_FreqGraphFirstPointReceived = true;
					m_FreqGraphStartTime = DateTime.Parse(chargeData.CurrDateTime);

					foreach (LineItem currentCurve in freqPane.CurveList)
					{
						IPointListEdit currentPointList = currentCurve.Points as IPointListEdit;
						currentPointList.Clear();
					}
					freqPane.XAxis.Scale.Min = 0;
					freqPane.XAxis.Scale.Max = 15;
				}

				// Make sure the curve list has correct number of curves
				if (grphFreqChart.GraphPane.CurveList.Count != 3) return;

				// Get the curveitems for the graph
				LineItem freqCurve = freqPane.CurveList[0] as LineItem;
				LineItem aveFreqCurve = freqPane.CurveList[1] as LineItem;
				LineItem fakeFreqCurve = freqPane.CurveList[2] as LineItem;

				if ((freqCurve == null) || (aveFreqCurve == null) || (fakeFreqCurve == null)) return;

				// Get the PointPairLists for the curves
				IPointListEdit freqPointList = freqCurve.Points as IPointListEdit;
				IPointListEdit aveFreqPointList = aveFreqCurve.Points as IPointListEdit;
				IPointListEdit fakePointList = fakeFreqCurve.Points as IPointListEdit;
				// If any list is null, exit because it doesn't support IPointListEdit and can't be edited
				if ((freqPointList == null) || (aveFreqPointList == null) || (aveFreqPointList == null)) return;

				// Get the elapsed time
				TimeSpan timeDiff = DateTime.Parse(chargeData.CurrDateTime).Subtract(m_FreqGraphStartTime);
				double elapsedTime = timeDiff.TotalMinutes;

//				msg = "UpdateFreqGraph: StartTime = " + m_FreqGraphStartTime.ToString() + ", CurrentTime = " + chargeData.CurrDateTime.ToString() +
//					", Elapsed Time = " + timeDiff.TotalMinutes.ToString();
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, msg);

				// Add the new points to the curves
				freqPointList.Add(elapsedTime, chargeData.FreqAsDouble);
				aveFreqPointList.Add(elapsedTime, chargeData.AveFreqAsDouble);
				fakePointList.Add(elapsedTime, chargeData.FreqAsDouble);

				//string tmpMsg = "freqPointList.Count = " + freqPointList.Count.ToString();
				//clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, tmpMsg);
				//tmpMsg = "aveFreqPointList.Count = " + aveFreqPointList.Count.ToString();
				//clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, tmpMsg);
				//tmpMsg = "fakePointList.Count = " + fakePointList.Count.ToString();
				//clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, tmpMsg);

				// Keep the X axis at 15 minutes, with one minor step between max X value and end of axis
				ZedGraph.Scale xScale = freqPane.XAxis.Scale;
				if (elapsedTime > xScale.Max - xScale.MinorStep)
				{
					xScale.Max = elapsedTime + xScale.MinorStep;
					xScale.Min = xScale.Max - 15.0;
				}

				// Make sure Y axes are rescaled to accomodate actual data
				grphFreqChart.AxisChange();
				//freqPane.Y2Axis.Scale.MinorStep = freqPane.Y2Axis.Scale.MajorStep / 2.0;

				// Force a redraw
				grphFreqChart.Invalidate();
			}	// End sub

			/// <summary>
			/// Updates the power plot based on incoming data
			/// </summary>
			/// <param name="chargeData">Object containing one charge data point</param>
			private void UpdatePowerGraph(clsChargeData chargeData)
			{
				string msg;

				GraphPane pwrPane = grphPwrChart.GraphPane;

				// If this is the first point in a new graph, then set appropriate class variables and clear point arrays
				if (!m_PwrGraphFirstPointReceived)
				{
					m_PwrGraphFirstPointReceived = true;
					m_PwrGraphStartTime = DateTime.Parse(chargeData.CurrDateTime);

					foreach (LineItem currentCurve in pwrPane.CurveList)
					{
						IPointListEdit currentPointList = currentCurve.Points as IPointListEdit;
						currentPointList.Clear();
					}
					pwrPane.XAxis.Scale.Min = 0;
					pwrPane.XAxis.Scale.Max = 15;
				}

				// Make sure the curve list has correct number of curves
				if (grphPwrChart.GraphPane.CurveList.Count != 2) return;

				// Get the curveitems for the graph
				LineItem socCurve = pwrPane.CurveList[0] as LineItem;
				LineItem rocCurve = pwrPane.CurveList[1] as LineItem;
				if ((socCurve == null) || (rocCurve == null)) return;

				// Get the PointPairLists for the curves
				IPointListEdit socPointList = socCurve.Points as IPointListEdit;
				IPointListEdit rocPointList = rocCurve.Points as IPointListEdit;
				// If any list is null, exit because it doesn't support IPointListEdit and can't be edited
				if ((socPointList == null) || (rocPointList == null)) return;

				// Get the elapsed time
				TimeSpan timeDiff = DateTime.Parse(chargeData.CurrDateTime).Subtract(m_FreqGraphStartTime);
				double elapsedTime = timeDiff.TotalMinutes;

//				msg = "UpdatePowerGraph: StartTime = " + m_FreqGraphStartTime.ToString() + ", CurrentTime = " + chargeData.CurrDateTime.ToString() +
//					", Elapsed Time = " + timeDiff.TotalMinutes.ToString();
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, msg);

				// Add the new points to the curves
				socPointList.Add(elapsedTime, chargeData.KWhrAsDouble);	// Actually SOC in %
				rocPointList.Add(elapsedTime, chargeData.ChargeAmps);	// Actually charge rate in kW

				// Keep the X axis at 15 minutes, with one minor step between max X value and end of axis
				ZedGraph.Scale xScale = pwrPane.XAxis.Scale;
				if (elapsedTime > xScale.Max - xScale.MinorStep)
				{
					xScale.Max = elapsedTime + xScale.MinorStep;
					xScale.Min = xScale.Max - 15.0;
				}

				// Make sure Y axes are rescaled to accomodate actual data
				grphPwrChart.AxisChange();
				//freqPane.Y2Axis.Scale.MinorStep = freqPane.Y2Axis.Scale.MajorStep / 2.0;

				// Force a redraw
				grphPwrChart.Invalidate();
			}	// End sub

			/// <summary>
			/// Converts a DateTime to decimal hours
			/// </summary>
			/// <param name="inpTime">Input time</param>
			/// <returns>Time in decimal hours (24 hour clock)</returns>
			private double ConvertTimeToDecimalHours(DateTime inpTime)
			{
				double hour = (double)inpTime.Hour;
				double minute = (double)inpTime.Minute;

				return hour + (minute / 60);
			}	// End sub

			/// <summary>
			/// Resets the frequency chart to zero
			/// </summary>
			private void ClearFreqGraph()
			{
				GraphPane freqPane = grphFreqChart.GraphPane;

				m_FreqGraphFirstPointReceived = false;
				foreach (LineItem currentCurve in freqPane.CurveList)
				{
					IPointListEdit currentPointList = currentCurve.Points as IPointListEdit;
					currentPointList.Clear();
				}
				// Force a redraw
				grphFreqChart.Invalidate();

			}	// End sub

			/// <summary>
			/// Resets the frequency chart to zero
			/// </summary>
			private void ClearPwrGraph()
			{
				GraphPane freqPane = grphPwrChart.GraphPane;

				m_PwrGraphFirstPointReceived = false;
				foreach (LineItem currentCurve in freqPane.CurveList)
				{
					IPointListEdit currentPointList = currentCurve.Points as IPointListEdit;
					currentPointList.Clear();
				}
				// Force a redraw
				grphPwrChart.Invalidate();

			}	// End sub

			/// <summary>
			/// Creates a random VIN
			/// </summary>
			/// <returns>VIN string</returns>
			private string CreateRandomVin()
			{
				string vin = "VIN";
				Random baseNumGen = new Random();

				vin += baseNumGen.Next(1, 9999999).ToString("0000000") + "_";

				vin += baseNumGen.Next(1, 9999).ToString("0000");

				return vin;
			}	// End sub
		#endregion

		#region "Button event handlers"
			/// <summary>
			/// Handles Open Port button
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnOpenPort_Click(object sender, EventArgs e)
			{
				if (!m_SerialPortOpen)
				{
					m_MainProgram.OpenPort();
				}
				else MessageBox.Show("Port already open");
			}	//End sub

			/// <summary>
			/// Handles Close Port button
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnClosePort_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					m_MainProgram.ClosePort();
				}
				else MessageBox.Show("Port already closed");
			}	// End sub

			/// <summary>
			/// Sets the debug logging level
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnDebugLogControl_Click(object sender, EventArgs e)
			{
				if (m_MainProgram.DebugLogging)
				{
					m_MainProgram.DebugLogging = false;
				}
				else m_MainProgram.DebugLogging = true;
			}	// End sub

			/// <summary>
			/// Enables/disables program pause
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnPauseControl_Click(object sender, EventArgs e)
			{
				if (m_MainProgram.PauseEnable)
				{
					m_MainProgram.PauseEnable = false;
				}
				else m_MainProgram.PauseEnable = true;
			}	// End sub

			/// <summary>
			/// Reads battery data from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnBattData_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					m_MainProgram.GetBatteryStatusFromBoard();
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Loads a price array
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnLoadPrices_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
//					LoadPriceArray();
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets charge rate data from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnRate_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetChargeRateFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets price data array from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnPrice_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetPriceFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets the VIN from the board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnVin_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetVinFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets the actual charge start time from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnActualChargeStartTime_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetActualChargeStartFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets the commanded charge end time from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnChargeEndCommanded_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetCommandedChargeEndTimeFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets current date/time from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnDate_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetDateTimeFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Sets the date and commanded charge stop time on the EVSE board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnSetDate_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (m_MainProgram.SetDate())
					{
						MessageBox.Show("Date set");
					}
					else MessageBox.Show("Problem setting date: " + m_MainProgram.Msg);
				}
				else
				{
					MessageBox.Show("Serial port not open");
				}
			}	// End sub

			/// <summary>
			/// Resets the battery SOC
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnResetSoc_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.ResetSoc()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Sends a custom command to the board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnCustomCmd_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.SendCustomCmd(txtCustomCmd.Text)) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Gets current state from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnStateRequest_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetCurrentStateFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub


			/// <summary>
			/// Handles button for requesting charge command from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnCommand_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetCurrentChargeCommandFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Handles request for battery charge data
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnChargeData_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetChargeStateFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else MessageBox.Show("Serial port not open");
			}	// End sub

			/// <summary>
			/// Handles refresh enable button
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnEnableRefresh_Click(object sender, EventArgs e)
			{
				if (m_RefreshTimer.Enabled)
				{
					m_RefreshTimer.Enabled = false;
					btnEnableRefresh.Text = "Enable Refresh";
				}
				else
				{
					m_RefreshTimer.Enabled = true;
					btnEnableRefresh.Text = "Disable Refresh";
				}
			}	// End sub

			private void btnResetPlots_Click(object sender, EventArgs e)
			{
				ClearFreqGraph();
				ClearPwrGraph();
			}	// End sub
		#endregion

		#region "Event handlers"
			/// <summary>
			/// Handles startup routines that must occur after form load
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			void m_StartupDelay_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
			{
				m_StartupDelayTimer.Enabled = false;

				// Initialize the main program class
				bool retVal = m_MainProgram.InitApplication();
				if (!retVal)
				{
					// Something went wrong on program startup
					MessageBox.Show(m_MainProgram.Msg);
					//m_MainProgram.Dispose();
					//m_MainProgram = null;
					//this.Close();
					Application.Exit();
					return;
				}

				// Assign serial port event handlers
				m_MainProgram.SerialPortStateChanged += new delSerialPortStateChanged(OnSerialPortStateChange);
				m_MainProgram.SerialPortDataReceived += new delSerialPortDataReceived(m_MainProgram_SerialPortDataReceived);

				// Open the serial port
				if (!m_MainProgram.OpenPort())
				{
					MessageBox.Show("Serial port not open. Program will not operate correctly until port is opened");
					return;
				}

				//// Request the max charge current from the board
				//if (m_SerialPortOpen) m_MainProgram.GetChargeConfigFromBoard();

				// Set up the refresh timer
				m_RefreshTimer = new System.Timers.Timer();
				m_RefreshTimer.Interval = Properties.Settings.Default.StatusRefreshInterval * 1000;	// Convert seconds to msec
				m_RefreshTimer.Elapsed += new System.Timers.ElapsedEventHandler(m_RefreshTimer_Elapsed);
				m_RefreshTimer.Enabled = false;
			}	// End sub

			/// <summary>
			/// Hendles periodic data update
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			void m_RefreshTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
			{
				// Do nothing if disconnected or charging
				if ((m_MainProgram.SystemState == SystemStates.NotConnected) || (m_MainProgram.SystemState == SystemStates.Charging)) return;

				// Get the current charge state from board
				m_MainProgram.GetChargeStateFromBoard();
			}	// End sub

			/// <summary>
			/// Handles display of raw serial port data
			/// </summary>
			/// <param name="data"></param>
			void m_MainProgram_SerialPortDataReceived(string data)
			{
				UpdateReceivedDataTextBox(data);
			}	// End sub

			/// <summary>
			/// Handles receipt of message for display on log screen
			/// </summary>
			/// <param name="direction">Message direction</param>
			/// <param name="msg">Message text</param>
			void m_MainProgram_StdMsgReceived(string direction, string msg)
			{
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "m_MainProgram_StdMsgReceived: msg=" + msg);

				// Forward the received message to the log viewing form
				clsMessageSender.SendLogMessage(direction, msg);
			}	// End sub

			/// <summary>
			/// Updates the display of port status
			/// </summary>
			/// <param name="portOpen"></param>
			void OnSerialPortStateChange(bool portOpen, string msg)
			{
				m_SerialPortOpen = portOpen;
				txtPortStatus.Text = msg;
			}	// End sub

			/// <summary>
			/// Closes objects and logs application exit
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
			{
				Properties.Settings.Default.DebugLogLevel = (m_MainProgram.DebugLogging) ? (int)clsLogTools.LogLevels.DEBUG : (int)clsLogTools.LogLevels.INFO;
				Properties.Settings.Default.PauseEnabled = m_MainProgram.PauseEnable;
				Properties.Settings.Default.Save();

				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "frmMain: Calling m_MainProgram.Dispose()");
				m_MainProgram.Dispose();
				m_MainProgram = null;

				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "===== Closing PHEV_01 =====");
			}	//End sub

			/// <summary>
			/// Gets the actual charge finish time from board
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnActualChargeFinishTime_Click(object sender, EventArgs e)
			{
				if (m_SerialPortOpen)
				{
					if (!m_MainProgram.GetActualChargeFinishTimeFromBoard()) MessageBox.Show(m_MainProgram.Msg);
				}
				else
				{
					MessageBox.Show("Serial port not open");
				}
			}	// End sub

			/// <summary>
			/// Select price profile 1
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void rbPriceProfile1_CheckedChanged(object sender, EventArgs e)
			{
//				if (rbPriceProfile1.Checked) m_SelectedProfileIndx = 0;
			}

			/// <summary>
			/// Select price profile 2
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void rbPriceProfile2_CheckedChanged(object sender, EventArgs e)
			{
//				if (rbPriceProfile2.Checked) m_SelectedProfileIndx = 1;
			}

			/// <summary>
			/// Select price profile 3
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void rbPriceProfile3_CheckedChanged(object sender, EventArgs e)
			{
//				if (rbPriceProfile3.Checked) m_SelectedProfileIndx = 2;
			}

			/// <summary>
			/// Select price profile 4
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void rbPriceProfile4_CheckedChanged(object sender, EventArgs e)
			{
//				if (rbPriceProfile4.Checked) m_SelectedProfileIndx = 3;
			}	// End sub

			/// <summary>
			/// Handles the Stop Charge button
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void btnStopCharge_Click(object sender, EventArgs e)
			{
				m_MainProgram.SetChargeMethod(ChargeMethods.Off);
			}	// End sub

			/// <summary>
			/// Sets the debug log level button caption and status
			/// </summary>
			/// <param name="debugEnabled"></param>
			void OnLogEnableChanged(bool debugEnabled)
			{
				if (debugEnabled)
				{
					btnDebugLogControl.Text = "Disable Debug Log";
					lblLogStatus.Text = "Debug logging enabled";
				}
				else
				{
					btnDebugLogControl.Text = "Enable Debug Log";
					lblLogStatus.Text = "Debug logging disabled";
				}
			}	// End sub
			
			/// <summary>
			/// Sets the pause enable button caption and status
			/// </summary>
			/// <param name="pauseEnabled"></param>
			void OnPauseEnableChanged(bool pauseEnabled)
			{
				if (pauseEnabled)
				{
					btnPauseControl.Text = "Disable Pause";
					lblPauseStatus.Text = "Pause enabled";
				}
				else
				{
					btnPauseControl.Text = "Enable Pause";
					lblPauseStatus.Text = "Pause disabled";
				}
			}	// End sub

			/// <summary>
			/// Handles receipt of date from board
			/// </summary>
			/// <param name="data">Date string</param>
			void m_MainProgram_DateReceived(string data)
			{
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Date received from EVSE");
				string dateStr = data.Replace("D=","");
			}	// End sub

			/// <summary>
			/// Handles receipt of charge data from EVSE
			/// </summary>
			/// <param name="chargeData">Object containing charge data</param>
			void m_MainProgram_ChargeDataReceived(clsChargeData chargeData)
			{
				// Update the frequency and power graphs
				UpdateFreqGraph(chargeData);
				UpdatePowerGraph(chargeData);
			}	// End sub

			/// <summary>
			/// Handles receipt of charge config data
			/// </summary>
			/// <param name="configData">Object containing charge config data</param>
			void m_MainProgram_ChargeConfigDataReceived(clsChargeConfigData configData)
			{
				// Force Y2 axis range on frequency graph
				GraphPane freqPane = grphFreqChart.GraphPane;

				double axisMax = configData.MaxAmps + 1;

				freqPane.Y2Axis.Scale.Min = 0;
				freqPane.Y2Axis.Scale.Max = axisMax;
				freqPane.Y2Axis.Scale.MajorStep = configData.MaxAmps / 5;
				freqPane.Y2Axis.Scale.MinorStep = freqPane.Y2Axis.Scale.MajorStep / 2;

				grphFreqChart.Invalidate();
			}	// End sub

			/// <summary>
			/// Handles receipt of a plot reset command
			/// </summary>
			void m_MainProgram_ResetPlotsReceived()
			{
				ClearFreqGraph();
				ClearPwrGraph();
			}	// End sub
		#endregion

		#region "Display update methods"
			private void UpdateReceivedDataTextBox(string text)
			{
				if (txtRcxData.InvokeRequired)
				{
					//					delUpdateReceivedMsgTextCallback d = new delUpdateReceivedMsgTextCallback(UpdateReceivedDataTextBox);
					delUpdateTextDisplay d = new delUpdateTextDisplay(UpdateReceivedDataTextBox);
					txtRcxData.BeginInvoke(d, new object[] { text });
				}
				else
				{
					txtRcxData.Text = text;
				}
			}	// End sub

			private void UpdateRadioButtonState(RadioButton radButton, bool enabled)
			{
				if (radButton.InvokeRequired)
				{
					delUpdateRadioButtonState d = new delUpdateRadioButtonState(UpdateRadioButtonState);
					radButton.BeginInvoke(d, new object[] { radButton, enabled });
				}
				else radButton.Enabled = enabled;
			}	// End sub
		#endregion
	}	// End class
}	// End namespce
