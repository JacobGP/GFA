﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace PHEV_01
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			try
			{
				Application.Run(new frmMain());
			}
			catch (Exception ex)
			{
				string errMsg = "Critical exception starting application";
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogSystem, clsLogTools.LogLevels.FATAL, errMsg, ex);
				return;
			}
		}	// End sub
	}	// End class
}	// End namespace
