﻿//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 06/11/2010
//
// Last modified 06/11/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;

namespace PHEV_01
{
	class clsSerialPortData
	{
		//*********************************************************************************************************
		// Class to hold data for a serial port
		//**********************************************************************************************************

		#region "Class variables"
			Handshake m_Handshake = Handshake.None;
			Parity m_Parity = Parity.None;
			StopBits m_StopBits = StopBits.None;
		#endregion

		#region "Properties"
			public int Baudrate { get; set; }
			public int Databits { get; set; }
			public string PortName { get; set; }

			public string HandshakeAsString
			{
				get { return m_Handshake.ToString(); }
				set
				{
					if (Enum.IsDefined(typeof(Handshake), value))
					{
						m_Handshake = (Handshake)Enum.Parse(typeof(Handshake), value);
					}
					else
					{
						m_Handshake = Handshake.None;
					}
				}
			}

			public Handshake HandShakeAsEnum { get { return m_Handshake; } }

			public string ParityAsString
			{
				get { return m_Parity.ToString(); }
				set
				{
					if (Enum.IsDefined(typeof(Parity), value))
					{
						m_Parity = (Parity)Enum.Parse(typeof(Parity),value);
					}
					else
					{
						m_Parity = Parity.None;
					}
				}
			}

			public Parity ParityAsEnum { get { return m_Parity; } }

			public string StopbitsAsString
			{
				get { return m_StopBits.ToString(); }
				set
				{
					if (Enum.IsDefined(typeof(StopBits), value))
					{
						m_StopBits = (StopBits)Enum.Parse(typeof(StopBits), value);
					}
					else
					{
						m_StopBits = StopBits.None;
					}
				}

			}

			public StopBits StopbitsAsEnum { get { return m_StopBits; } }
		#endregion
	}	// End class
}	// End namespace
