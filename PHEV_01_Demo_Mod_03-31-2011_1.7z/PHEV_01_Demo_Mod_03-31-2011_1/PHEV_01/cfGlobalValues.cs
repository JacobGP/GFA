﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 09/09/2010
//
// Last modified 09/09/2010
//*********************************************************************************************************

namespace PHEV_01
{
	#region "Global enums"
		public enum SystemStates : short
		{
			NotConnected = 0,
			Connected = 1,
			Authenticating = 2,
			Binding = 3,
			Precharge = 4,
			ChargeDelay = 5,
			Charging = 6,
			ChargeComplete = 7,
			Billing = 8,
			InvalidState = 255
		}

		public enum ChargeMethods : short
		{
			NC = 0,
			Off = 1,
			Pause = 2,
			Done = 3,
			Charge_Now = 4,
			Demand_Response = 5,
			Time_of_Use = 6,
			Regulation_Services = 7,
			On = 8,
			Test = 9,
			Other = 99
		}
	#endregion

	#region "Global delegates"
		public delegate void delDebugLogEnableChanged(bool debugEnabled);

		public delegate void delPauseEnableChanged(bool pauseEnabled);

		public delegate void delSerialPortStateChanged(bool portOpen, string msg);

		public delegate void delSerialPortDataReceived(string data);

		public delegate void delChargeRateDataReceived(double[] data);

		public delegate void delPriceDataReceived(double[] data);

		public delegate void delDateReceived(string data);

		public delegate void delSystemStateChanged(SystemStates newState);

		public delegate void delSystemMessage(string msg);

		public delegate void delChargeDataReceived(clsChargeData chargeData);

		public delegate void delChargeEndTimeReceived(string data);

		public delegate void delChargeBeginTimeReceived(string data);

		public delegate void delBatteryDataReceived(clsBatteryData battData);

		public delegate void delSystemPaused();

		public delegate void delChargeConfigDataReceived(clsChargeConfigData configData);

		public delegate void delLogMessage(string direction, string msg);

		public delegate void del2847MsgReceived(string direction, string msg);

		public delegate void delResetPlotsReceived();
	#endregion

}	// End namespace