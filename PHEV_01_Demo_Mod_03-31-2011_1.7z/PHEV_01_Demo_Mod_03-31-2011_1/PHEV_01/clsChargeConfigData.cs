﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 10/11/2010
//
// Last modified 10/11/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	public class clsChargeConfigData
	{
		//*********************************************************************************************************
		// Holds charge configuration data
		//**********************************************************************************************************

		#region "Constants"
		#endregion

		#region "Class variables"
		#endregion

		#region "Delegates"
		#endregion

		#region "Events"
		#endregion

		#region "Properties"
			public double MaxVolts { get; set; }

			public double MaxAmps { get; set; }

			public double MaxWatts { get; set; }

			public string Misc { get; set; }
		#endregion

		#region "Constructors"
		#endregion

		#region "Methods"
		#endregion
	}	// End class
}	// End namespace
