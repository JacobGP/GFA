﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 11/04/2010
//
// Last modified 11/04/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	class enumListViewComparerMode
	{
		//*********************************************************************************************************
		// Enums for use by Listview classListViewItemComparer
		//**********************************************************************************************************

		#region "Enums"
		/// <summary>
		/// Used for determining if column is numeric or string
		/// </summary>
		public enum SortModeConstants
		{
			text,
			numeric
		}
		#endregion

	}	// End class
}	// End namespace
