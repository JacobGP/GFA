﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 07/01/2010
//
// Last modified 07/01/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace PHEV_01
{
	class clsPriceFileTools
	{
		//*********************************************************************************************************
		// Class for handling price data in files
		//**********************************************************************************************************

		#region "Constants"
		#endregion

		#region "Class variables"
			static string m_Msg = "";
			static string m_ProgramFolder;
		#endregion

		#region "Delegates"
		#endregion

		#region "Events"
		#endregion

		#region "Properties"
			public static string Message { get { return m_Msg; } }
		#endregion

		#region "Constructors"
			static clsPriceFileTools()
			{
				FileInfo fi = new FileInfo(System.Windows.Forms.Application.ExecutablePath);
				m_ProgramFolder = fi.DirectoryName;
			}	// End sub
		#endregion

		#region "Methods"
			/// <summary>
			/// Creates a price array from a line of text input
			/// Input formatted as "hhmm:cccc.c,hhmm:cccc.c,......,etc) using 24-hour clock. Starts at time 0000 = midnight, ends at 2359 = 11:59 PM
			/// </summary>
			/// <param name="priceDataLine">Input line</param>
			/// <returns>Array of prices</returns>
			private static double[] MakePriceArrayFromString(string priceDataLine)
			{
				double[] priceArray = null;

				// Split the input string into time/price pairs
				string[] timePricePairs = priceDataLine.Split(',');
				if (timePricePairs.Length == 0)
				{
					m_Msg = "No time price pairs in input line " + priceDataLine;
					return priceArray;
				}

				// Setup indices for stroring time/price data into price array
				//	Storage starts at maximum and goes backwards to midnight (time = 0 or price array index = 0)
				priceArray = new double[96];
				int priceArrayIndx = priceArray.Length - 1;
				int timePriceIndx = timePricePairs.Length - 1;
				double currTime = ConvertTimeStrToDecimalHour("2345");
				double currPriceTime;
				double currPrice;

				// Start processing the time/price array
				while (timePriceIndx >= 0)
				{
					string[] tmpTimePricePair = timePricePairs[timePriceIndx].Split(':');
					currPriceTime = ConvertTimeStrToDecimalHour(tmpTimePricePair[0]);
					currPrice = double.Parse(tmpTimePricePair[1]);
					while ((currTime >= currPriceTime) && (priceArrayIndx >= 0))
					{
						//string dumMsg = "timePriceIndx=" + timePriceIndx.ToString() + ", currTime=" + currTime.ToString() + ", currPriceTime=" + currPriceTime.ToString();
						//dumMsg += ", priceArrayIndx=" + priceArrayIndx.ToString() + ", currPrice=" + currPrice.ToString();
						//System.Diagnostics.Debug.WriteLine(dumMsg);

						priceArray[priceArrayIndx] = currPrice;
						priceArrayIndx--;
						currTime -= 0.25;
					}
					timePriceIndx--;
				}

				return priceArray;
			}	// End sub

			/// <summary>
			/// Converts a time string in 24-hour "hhmm" format to a decimal hour
			/// </summary>
			/// <param name="timeStr">Input time string</param>
			/// <returns>Decimal hour</returns>
			private static double ConvertTimeStrToDecimalHour(string timeStr)
			{
				//NOTE: Assumes time string is always 4 characters long
				double hours = double.Parse(timeStr.Substring(0, 2));
				double minutes = double.Parse(timeStr.Substring(2,2));
				
				return hours + (minutes/60);
			}	// End sub

			/// <summary>
			/// Reads a file containing time/price schedules
			/// </summary>
			/// <returns>Collection of schedule arrays on success; NULL otherwise</returns>
			public static List<double[]> ReadInputFile()
			{
				string fileNamePath = Path.Combine(m_ProgramFolder, Properties.Settings.Default.PriceProfileFileName);
				string[] fileContents = null;

				// Get an array of lines containing time/price data
				try
				{
					if (File.Exists(fileNamePath))
					{
						fileContents = File.ReadAllLines(fileNamePath);
					}
					else
					{
						m_Msg = "Price list file " + fileNamePath + " not found";
						return null;
					}
				}
				catch (Exception ex)
				{
					m_Msg = "Exception reading price list input file: " + ex.Message;
					return null;
				}

				if (fileContents == null)
				{
					m_Msg = "Null value returned when reading price list file contents";
					return null;
				}

				if (fileContents.Length < 1)
				{
					m_Msg = "No values returned from price list file";
					return null;
				}

				List<double[]> priceLists = new List<double[]>();

				foreach (string priceListStr in fileContents)
				{
					if (priceListStr.Contains('#')) continue;
					double[] tmpList = MakePriceArrayFromString(priceListStr);
					if ((tmpList != null) && (tmpList.Length > 0))
					{
						priceLists.Add(tmpList);
					}
				}

				if (priceLists.Count > 0)
				{
					return priceLists;
				}
				else
				{
					m_Msg = "No price lists found in file";
					return null;
				}

			}	// End sub
		#endregion
	}	// End class
}	// End namespace
