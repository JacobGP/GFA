﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 11/04/2010
//
// Last modified 11/04/2010
//*********************************************************************************************************
using System.Windows.Forms;

namespace PHEV_01
{
	public partial class frmLogWindow : Form
	{
		//*********************************************************************************************************
		// Form for display of messages
		//**********************************************************************************************************

		#region "Constants"
			const int MAX_LISTVIEW_COUNT = 500;
			const int MIN_LISTVIEW_COUNT = 100;
		#endregion

		#region "Delegates"
			delegate void delUpdateListView(ListViewItem newItem);
		#endregion

		#region "Class variables"
			long m_Id = 0;
			int m_LastColumnSelected = 0;
			bool m_SortAscending = true;
		#endregion

		#region "Constructors"
			public frmLogWindow()
			{
				InitializeComponent();

				// Add handler for receipt of log messages
				clsMessageSender.LogMessageSent += new delLogMessage(AddLogItem);
			}	// End sub
		#endregion

		#region "Methods"
			/// <summary>
			/// Sorts a listview based on the column that was clicked
			/// </summary>
			/// <param name="e">Column click event argument object</param>
			private void SortListView(ColumnClickEventArgs e)
			{
				// If selected column is smae as previously selected column, then reverse sort order.
				// Otherwise, sort newly selected column in ascending order
				if (e.Column == m_LastColumnSelected)
				{
					m_SortAscending = !m_SortAscending;
				}
				else
				{
					m_SortAscending = true;
					m_LastColumnSelected = e.Column;
				}

				// Perform sort. Column 0 is numeric; Column 1 is text
				if (e.Column == 0)
				{
					// Use numeric sort
					lvLogList.ListViewItemSorter = new clsListViewItemComparer(e.Column, m_SortAscending, enumListViewComparerMode.SortModeConstants.numeric);
				}
				else
				{
					// Use string sort
					lvLogList.ListViewItemSorter = new clsListViewItemComparer(e.Column, m_SortAscending, enumListViewComparerMode.SortModeConstants.text);
				}
			}	// End sub

			/// <summary>
			/// Deletes listview items to keep length reasonable
			/// </summary>
			private void ClearExcessListviewItems()
			{
				if (lvLogList.Items.Count < MAX_LISTVIEW_COUNT) return;	// Nothing needed

				int numItemsToDelete = lvLogList.Items.Count - MIN_LISTVIEW_COUNT;

				// Cycle through listview, removing as many items as needed
				lvLogList.BeginUpdate();
				for (int cntr = 0; cntr < numItemsToDelete; cntr++)
				{
					lvLogList.Items.RemoveAt(0);
				}
				lvLogList.EndUpdate();
			}	// End sub
		#endregion

		#region "Event handlers"
			/// <summary>
			/// Handles listview column header click event
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void lvLogList_ColumnClick(object sender, ColumnClickEventArgs e)
			{
				SortListView(e);
			}	// End sub

			/// <summary>
			/// Adds a new message to the log listview
			/// </summary>
			/// <param name="msg">Message to log</param>
			private void AddLogItem(string direction, string msg)
			{
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "AddLogItem: msg=" + msg);

				m_Id++;
				ListViewItem newItem = new ListViewItem(m_Id.ToString());
				newItem.SubItems.Add(direction);
				newItem.SubItems.Add(msg);

				UpdateListView(newItem);
			}	// End sub

			/// <summary>
			/// Disconnects event handlers when form closes
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void frmLogWindow_FormClosing(object sender, FormClosingEventArgs e)
			{
				clsMessageSender.LogMessageSent -= AddLogItem;
			}	// End sub
		#endregion

		#region "Display update methods"
			/// <summary>
			/// Adds an item to the the listview, using a delegate if necessary
			/// </summary>
			/// <param name="newItem">Item to add</param>
			private void UpdateListView(ListViewItem newItem)
			{
				if (lvLogList.InvokeRequired)
				{
					delUpdateListView d = new delUpdateListView(UpdateListView);
					lvLogList.BeginInvoke(d, new object[] { newItem });
				}
				else
				{
					lvLogList.Items.Add(newItem);
					ClearExcessListviewItems();
					colhdrDesc.Width = -1;
				}
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
