﻿//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 06/11/2010
//
// Last modified 06/11/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Threading;

namespace PHEV_01
{
	#region "Namespace delegates"
		public delegate void delDataReceived(string data);
	#endregion

	class clsSerPortTools : IDisposable
	{
		//*********************************************************************************************************
		// General class for control of serial port
		//**********************************************************************************************************

		#region "Constants"
		#endregion

		#region "Class variables"
			SerialPort m_SerialPort;
			string m_Msg = "";
			Thread m_ReadThread;
			bool m_ContinueRead = false;
		#endregion

		#region "Internal Delegates"
		#endregion

		#region "Events"
			public event delDataReceived DataReceived;
		#endregion

		#region "Properties"
			public string Msg { get { return m_Msg; } }

			public bool PortOpen
			{
				get
				{
					if (m_SerialPort != null)
					{
						return m_SerialPort.IsOpen;
					}
					else
					{
						return false;
					}
				}
			}

			public string PortName { get { return m_SerialPort.PortName; } }
		#endregion

		#region "Constructors"
			/// <summary>
			/// Constructor
			/// </summary>
			/// <param name="portData">Object containing serial port config parameters</param>
			public clsSerPortTools(clsSerialPortData portData)
			{
				InitPort(portData);
			}	// End sub
		#endregion

		#region "Methods"
			/// <summary>
			/// Initializes the serial port
			/// </summary>
			/// <param name="portData">Object containing serial port config parameters</param>
			private void InitPort(clsSerialPortData portData)
			{
				m_SerialPort = new SerialPort();
				m_SerialPort.BaudRate = portData.Baudrate;
				m_SerialPort.DataBits = portData.Databits;
				m_SerialPort.Handshake = portData.HandShakeAsEnum;
				m_SerialPort.Parity = portData.ParityAsEnum;
				m_SerialPort.PortName = portData.PortName;
				m_SerialPort.StopBits = portData.StopbitsAsEnum;
				m_SerialPort.ReadTimeout = 500;
				m_SerialPort.WriteTimeout = 500;
			}	// End sub

			/// <summary>
			/// Opens a serial port
			/// </summary>
			/// <returns>TRUE for success; FALSE othersise, with error message in Msg property</returns>
			public bool OpenPort()
			{
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSeraiPort.OpenPort: Opening serial port");
				if (m_SerialPort != null)
				{
					if (!m_SerialPort.IsOpen)
					{
						try
						{
							m_SerialPort.Open();
//							m_PortOpen = true;
							// Start listening for incoming data
							m_ReadThread = new Thread(ReadPort);
							m_ContinueRead = true;
							m_ReadThread.Start();
							return true;
						}
						catch (Exception ex)
						{
							m_Msg = "Exception opening port " + m_SerialPort.PortName + ": " + ex.Message;
//							m_PortOpen = false;
							return false;
						}
					}
					else
					{
						// Port is already open
//						m_PortOpen = true;
						return true;
					}
				}
				else
				{
					// Port not initialized
					m_Msg = "Port not initialized";
//					m_PortOpen = false;
					return false;
				}
			}	// End sub

			/// <summary>
			/// Closes a serial port
			/// </summary>
			/// <returns>TRUE for success; FALSE othersise, with error message in Msg property</returns>
			public bool ClosePort()
			{
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSeraiPort.ClosePort: Closing serial port");
				
				if (m_SerialPort != null)
				{
					if (m_SerialPort.IsOpen)
					{
						try
						{
							// Stop listening for input
							m_ContinueRead = false;

//							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSeraiPort.ClosePort: Thread = " + Thread.CurrentThread.Name);
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSeraiPort.ClosePort: Joining read thread");

							m_ReadThread.Join();
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSeraiPort.ClosePort: Read thread exited");

							// Close the port
							m_SerialPort.Close();
							return true;
						}
						catch (Exception ex)
						{
							m_Msg = "Exception closing port " + m_SerialPort.PortName + ": " + ex.Message;
							return false;
						}
					}
					else
					{
						// Port is already closed
						return true;
					}
				}
				else
				{
					// Port not initialized. This is OK, so do nothing
					m_Msg = "Port not initialized";
					return true;
				}
			}	// End sub

			/// <summary>
			/// Writes a string to the serial port
			/// </summary>
			/// <param name="msg">Message to write</param>
			/// <returns>TRUE for success; FALSE for failure. Error is in Msg property</returns>
			public bool SendMsg(string msg)
			{
				if (m_SerialPort.IsOpen)
				{
					try
					{
						m_SerialPort.Write(msg);
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.SendMsg: Sent string '" + msg + "'");
						return true;
					}
					catch (Exception ex)
					{
						m_Msg = "Exception writing to port: " + ex.Message;
						return false;
					}
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Reads data from the serial port
			/// </summary>
			public void ReadPort()
			{
				System.Threading.Thread.CurrentThread.Name = "ReadPortThread";

//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.ReadPort: Thread = " + Thread.CurrentThread.Name +
//					", m_ContinueRead = " + m_ContinueRead.ToString());

				while (m_ContinueRead)
				{
//					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.ReadPort: m_ContinueRead = " + m_ContinueRead.ToString());
					try
					{
						while ((m_SerialPort.BytesToRead > 0) && (m_ContinueRead))
						{
							string message = m_SerialPort.ReadLine();

							System.Diagnostics.Debug.Write("clsSerPortTools.ReadPort: Message = " + message);
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.ReadPort: m_ContinueRead = " + m_ContinueRead.ToString());
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.ReadPort: message = '" + message + "'");

							message = StripColon(message);
							if (DataReceived != null) DataReceived(message.Replace("\r", ""));
						}
					}
					catch (TimeoutException) { }
				
					Thread.Sleep(100);
				}

//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.ReadPort: Exiting method/thread");

			}	// End sub

			/// <summary>
			/// Removes stray return codes from beginning of string
			/// NOYE: This function will need modification when Rick changes message formats
			/// </summary>
			/// <param name="inpStr">Input string</param>
			/// <returns>Input string without stray codes</returns>
			private string StripColon(string inpStr)
			{
				if (inpStr.Contains(':'))
				{
					int charPosition = inpStr.IndexOf(":", 0, 3);
					if (charPosition < 0) return inpStr;	// ":" not found. Shouldn't ever happen, but.....
					return inpStr.Substring(charPosition + 1);
				}
				else return inpStr;
			}
		#endregion

		#region IDisposable Members
			public void Dispose()
			{
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsSerPortTools.Dispose: Executing method");
				if (m_SerialPort != null)
				{
					if (m_SerialPort.IsOpen)
					{
						try
						{
							ClosePort();
						}
						catch
						{
							// Do nothing; This just prevents a program crash
						}
					}
				}
				m_SerialPort = null;
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
