﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 09/24/2010
//
// Last modified 09/24/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	public class clsEnergyRequestData
	{
		//*********************************************************************************************************
		// Holds data from an energy request message
		//**********************************************************************************************************

		#region "Class variables"
			long m_WattHours = 0;
		#endregion

		#region "Properties"
			public int MaxChargeAmps { get; set; }

			public long WattHours
			{
				get { return m_WattHours; }
				set { m_WattHours = value; }
			}

			public double KiloWattHours { get { return (double)m_WattHours / 1000; } }
		#endregion
	}	// End class
}	// End namespace
