﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 06/14/2010
//
// Last modified 06/14/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace PHEV_01
{
	public class clsMsgTools
	{
		//*********************************************************************************************************
		// Class for creating and handling messages
		//**********************************************************************************************************

		#region "Enums"
			public enum QueryCodes
			{
				BATTERY_STATUS,
				RATE_SCHEDULE,
				ACTUAL_CHARGE_START_TIME,
				ACTUAL_CHARGE_STOP_TIME,
				PRICE_SCHEDULE,
				VIN,
				COMMAND,
				CHARGE_FINISH_COMMANDED,
				DATE,
				STATE,
				CHARGE_STATE,
				CHARGE_CONFIG
			}
		#endregion

		#region "Constants"
			const int NUMBER_OF_TIME_INTERVALS = 96;
		#endregion

		#region "Class variables"
			static string m_Msg = "";
		#endregion

		#region "Delegates"
		#endregion

		#region "Events"
		#endregion

		#region "Properties"
			public static string Msg { get { return m_Msg; } }
		#endregion

		#region "Constructors"
		#endregion

		#region "Methods"
			/// <summary>
			/// Creates a formatted date message
			/// </summary>
			/// <returns>Date message</returns>
			public static string CreateDateMessage()
			{
				DateTime currDate = DateTime.Now;
				TimeZone localTime = TimeZone.CurrentTimeZone;
				bool isDaylightSavings = localTime.IsDaylightSavingTime(currDate);
				string retStr = "D=" + currDate.ToString("HH,mm,ss,dd,MM,yyyy,");
				if (isDaylightSavings)
				{
					retStr = retStr + "1";
				}
				else
				{
					retStr = retStr + "0";
				}

				return AddStartEndChars(retStr);
			}	// End sub

			/// <summary>
			/// Creates specified command message. (Command code "C=x")
			/// </summary>
			/// <param name="cmdCode">Code for comamnd</param>
			/// <returns></returns>
			public static string CreateChargeModeMessage(ChargeMethods chgMethod)
			{
				string retStr = "C=" + ((int)chgMethod).ToString();
				return AddStartEndChars(retStr);
			}	// End sub

			/// <summary>
			/// Creates specified command message. (Command code "V=x")
			/// </summary>
			/// <param name="cmdCode">Code for comamnd</param>
			/// <returns></returns>
			public static string CreateVinMessage(string vin)
			{
				string retStr = "V=" + vin;
				return AddStartEndChars(retStr);
			}	// End sub

			/// <summary>
			/// Creates a message to enable/disable test mode
			/// </summary>
			/// <param name="useTestMode">Flag to indicate desired test mode status</param>
			/// <returns>Command string</returns>
			public static string CreateTestModeMessage(bool useTestMode)
			{
				string retString = "T=" + ((useTestMode) ? "1" : "0");
				return AddStartEndChars(retString);
			}	// End sub

			/// <summary>
			/// Sets charge completion time
			/// </summary>
			/// <param name="inpTime">Beginning time</param>
			/// <returns>String for sending to board</returns>
			public static string CreateChargeCompleteTimeMessage(DateTime inpTime)
			{
				TimeZone localTime = TimeZone.CurrentTimeZone;
				bool isDaylightSavings = localTime.IsDaylightSavingTime(inpTime);
				string retStr = "M=" + inpTime.ToString("HH,mm,ss,dd,MM,yyyy,");
				if (isDaylightSavings)
				{
					retStr = retStr + "1";
				}
				else
				{
					retStr = retStr + "0";
				}

				return AddStartEndChars(retStr);
			}// End sub

			/// <summary>
			/// Adds the start-of-message and end-of-message chars to a string
			/// </summary>
			/// <param name="inpStr">Message string</param>
			/// <returns>Message string with start/end chars</returns>
			public static string AddStartEndChars(string inpStr)
			{
				return inpStr + Environment.NewLine;
			}	// End sub

			/// <summary>
			/// Creates string for querying control board
			/// </summary>
			/// <param name="msgCode">Enum representing type of query</param>
			/// <returns>String for sending to board</returns>
			public static string CreateQueryMsg(QueryCodes msgCode)
			{
				string code = "";

				switch (msgCode)
				{
					case QueryCodes.ACTUAL_CHARGE_START_TIME:
						code = "S";
						break;
					case QueryCodes.ACTUAL_CHARGE_STOP_TIME:
						code = "A";
						break;
					case QueryCodes.BATTERY_STATUS:
						code = "B";
						break;
					case QueryCodes.CHARGE_FINISH_COMMANDED:
						code = "M";
						break;
					case QueryCodes.COMMAND:
						code = "C";
						break;
					case QueryCodes.DATE:
						code = "D";
						break;
					case QueryCodes.PRICE_SCHEDULE:
						code = "P";
						break;
					case QueryCodes.RATE_SCHEDULE:
						code = "R";
						break;
					case QueryCodes.VIN:
						code = "V";
						break;
					case QueryCodes.STATE:
						code = "Y";
						break;
					case QueryCodes.CHARGE_STATE:
						code = "X";
						break;
					case QueryCodes.CHARGE_CONFIG:
						code = "O";
						break;
				}

				return AddStartEndChars(code + "?");
			}	// End sub

			/// <summary>
			/// Converts incoming data message into an array of cost data
			/// </summary>
			/// <param name="msg">Incoming data message</param>
			/// <returns>Cost data array</returns>
			public static double[] MakeCostArrayFromMsg(string msg)
			{
				// Remove the "P=" and leading spaces
				string newMsg = msg.Replace("P=", "");
				string trimmedMsg = newMsg.TrimStart(' ');
				
				// Split the message into fields
				string[] fieldListStr = trimmedMsg.Split(',');

				if (fieldListStr.Length != NUMBER_OF_TIME_INTERVALS)
				{
					// There's a problem with the data
					m_Msg = "MakeCostArrayFromMsg: Invalid number of data fields (" + fieldListStr.Length.ToString() + ")";
					return null;
				}

				double[] costArray = new double[fieldListStr.Length];

				try
				{
					for (int indx = 0; indx < fieldListStr.Length; indx++)
					{
						costArray[indx] = double.Parse(fieldListStr[indx]) / 1000;
					}
				}
				catch (Exception ex)
				{
					m_Msg = "Exception parsing string in MakeCostArrayFromMessage: " + ex.Message;
					return null;
				}
				return costArray;
			}	// End sub

			/// <summary>
			/// Converts incoming data message into an array of charge rate data
			/// </summary>
			/// <param name="msg">Incoming data message</param>
			/// <returns>Charge rate data array</returns>
			public static double[] MakeRateArrayFromMsg(string msg)
			{
				// Remove the "R=" and leading spaces
				string newMsg = msg.Replace("R=", "");
				string trimmedMsg = newMsg.TrimStart(' ');

				// Split the message into fields
				string[] fieldListStr = trimmedMsg.Split(',');

				if (fieldListStr.Length != NUMBER_OF_TIME_INTERVALS)
				{
					// There's a problem with the data
					m_Msg = "MakeRateArrayFromMsg: Invalid number of data fields (" + fieldListStr.Length.ToString() + ")";
					return null;	
				}

				double[] rateArray = new double[fieldListStr.Length];

				try
				{
					for (int indx = 0; indx < fieldListStr.Length; indx++)
					{
						rateArray[indx] = double.Parse(fieldListStr[indx]);
					}
				}
				catch (Exception ex)
				{
					m_Msg = "Exception parsing string in MakeRateArrayFromMessage: " + ex.Message;
					return null;
				}

				return rateArray;
			}	// End sub

			/// <summary>
			/// Parses a charge data message
			/// </summary>
			/// <param name="msg">Input message</param>
			/// <returns>Output charge data</returns>
			public static clsChargeData GetChargeDataFromMsg(string msg)
			{
				string newMsg = msg.Replace("X=","");

				// Split the message into fields
				string[] fieldListStr = newMsg.Split(',');

				if (fieldListStr.Length != 7)
				{
					// There's a problem with the data
					m_Msg = "GetChargeDataFromMsg: Invalid number of data fields (" + fieldListStr.Length.ToString() + ")";
					return null;
				}

				// Store the fields in a class object
				clsChargeData chargeData = new clsChargeData();

				try
				{
					chargeData.FreqAsLong = long.Parse(fieldListStr[0]);
					chargeData.AveFreqAsLong = long.Parse(fieldListStr[1]);
					chargeData.ChargeAmps = int.Parse(fieldListStr[2]);
					chargeData.SOC = int.Parse(fieldListStr[3]);
					chargeData.WattSecAsLong = long.Parse(fieldListStr[4]);
					chargeData.TotalCostAsLong = long.Parse(fieldListStr[5]);
					chargeData.CurrDateTime = fieldListStr[6];
				}
				catch (Exception ex)
				{
					m_Msg = "Exception parsing charge data message: " + ex.Message;
					return null;
				}

				return chargeData;
			}	// End sub

			/// <summary>
			/// Parses a battery data message
			/// </summary>
			/// <param name="msg">String containing battery data message</param>
			/// <returns>Output battery data</returns>
			public static clsBatteryData GetBatteryDataFromMsg(string msg)
			{
				string newMsg = msg.Replace("B=", "");

				// Split the message into fields
				string[] fieldListStr = newMsg.Split(',');

				if (fieldListStr.Length != 8)
				{
					// There's a problem with the data
					m_Msg = "GetBatteryDataFromMsg: Invalid number of data fields (" + fieldListStr.Length.ToString() + ")";
					return null;
				}

				// Store the fields in a class object
				clsBatteryData battData = new clsBatteryData();

				try
				{
					battData.SOC = int.Parse(fieldListStr[0]);
					battData.Volts = double.Parse(fieldListStr[1]);
					battData.Amps = double.Parse(fieldListStr[2]);
					battData.Capacity = double.Parse(fieldListStr[3]);
					battData.Watts = double.Parse(fieldListStr[4]);
				}
				catch (Exception ex)
				{
					m_Msg = "Exception parsing battery data message: " + ex.Message;
					return null;
				}

				return battData;
			}	// End sub

			/// <summary>
			/// Builds the command for sending the price schedule to the board
			/// </summary>
			/// <param name="priceArray">Array of data for prices</param>
			/// <returns>Command string for sending to board</returns>
			public static string CreatePriceUpdateMsg(double[] priceArray)
			{
				StringBuilder priceData = new StringBuilder("P=1,");

				// Add all elements except the last one
				for (int i = 0; i < priceArray.Length-1; i++)
				{
					priceData.Append((priceArray[i] * 1000).ToString("0000") + ",");
				}

				// Add the last element
				priceData.Append((priceArray[priceArray.Length - 1] * 1000).ToString("0000"));

				return AddStartEndChars(priceData.ToString());
			}	// End sub

			/// <summary>
			/// Builds a command to set the system state
			/// </summary>
			/// <param name="newState">Enum representing new state to include in command</param>
			/// <returns>Command string</returns>
			public static string CreateSetSystemStateMsg(SystemStates newState)
			{
				string retStr = "Y=" + ConvertStateToShort(newState).ToString();
				return AddStartEndChars(retStr);
			}	// End sub

			/// <summary>
			/// Converts a SystemStates enum to an integer
			/// </summary>
			/// <param name="inpState">Input enum</param>
			/// <returns>Integer equivalent to input value</returns>
			public static short ConvertStateToShort(SystemStates inpState)
			{
				return (short)inpState;
			}	// End sub

			/// <summary>
			/// Converts an integer to a SystemState enum
			/// </summary>
			/// <param name="inpVal">Input integer</param>
			/// <returns>Enum equivalent to input value</returns>
			public static SystemStates ConvertShortToSystemState(short inpVal)
			{
				if (Enum.IsDefined(typeof(SystemStates),inpVal))
				{
					return (SystemStates)inpVal;
				}
				else return SystemStates.InvalidState;
			}	// End sub

			/// <summary>
			/// Converts an energy request message to a class holding data
			/// </summary>
			/// <param name="msg">Input message</param>
			/// <returns>Energy request data object</returns>
			public static clsEnergyRequestData GetEnergyDataFromMessage(string msg)
			{
				// Strip off "E="
				string tmpStr = msg.Replace("E=", "");

				// Split the message into parts
				string[] tmpStrArray = tmpStr.Split(',');

				if (tmpStrArray.Length != 2)
				{
					// Invalid field count
					m_Msg = "Invalid field count (" + tmpStrArray.Length.ToString() + ") when splitting message '" + msg + "'";
					return null;
				}

				clsEnergyRequestData tmpRetVal = new clsEnergyRequestData();

				try
				{
					tmpRetVal.WattHours = long.Parse(tmpStrArray[0]);
					tmpRetVal.MaxChargeAmps = int.Parse(tmpStrArray[1]);
					return tmpRetVal;
				}
				catch (Exception ex)
				{
					m_Msg = "Exception converting energy request: " + ex.Message;
					return null;
				}
			}	// End sub

			/// <summary>
			/// Converts text message to charge config data class
			/// </summary>
			/// <param name="msg">Input message string</param>
			/// <returns>Charge config data object</returns>
			public static clsChargeConfigData GetChargeConfigDataFromMessage(string msg)
			{
				// Strip off "O="
				string tmpStr = msg.Replace("O=", "");

				// Split the message into parts
				string[] tmpStrArray = tmpStr.Split(',');

				if (tmpStrArray.Length != 4)
				{
					// Invalid field count
					m_Msg = "Invalid field count (" + tmpStrArray.Length.ToString() + ") when splitting message '" + msg + "'";
					return null;
				}

				clsChargeConfigData tmpRetVal = new clsChargeConfigData();

				try
				{
					tmpRetVal.MaxVolts = double.Parse(tmpStrArray[0]);
					tmpRetVal.MaxAmps = double.Parse(tmpStrArray[1]);
					tmpRetVal.MaxWatts = double.Parse(tmpStrArray[2]);
					tmpRetVal.Misc = tmpStrArray[3];

					return tmpRetVal;
				}
				catch (Exception ex)
				{
					m_Msg = "Exception converting charge config data: " + ex.Message;
					return null;
				}
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
