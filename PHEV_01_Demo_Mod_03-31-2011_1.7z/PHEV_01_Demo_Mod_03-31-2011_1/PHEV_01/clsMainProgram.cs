﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 09/09/2010
//
// Last modified 09/09/2010
//						03/21/2011 (DAC) - Modified to reset plots on receipt of A= command
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace PHEV_01
{
	class clsMainProgram : IDisposable
	{
		//*********************************************************************************************************
		// Main class for running application
		//**********************************************************************************************************

		#region "Enums"
			private enum PauseState
			{
				Send_Date_Time,
				Send_Bound,
				Send_Mode,
				None
			}
		#endregion

		#region "Constants"
		#endregion

		#region "Class variables"
			string m_Msg = "";
			bool m_DebugLoggingEnabled = false;
			bool m_PauseEnabled = false;
			string m_SerPortName = "";
			clsSerPortTools m_SerPort;
			SystemStates m_CurrentState = SystemStates.NotConnected;
			double[] m_PriceArray;
			ChargeMethods m_ChargeMethod = ChargeMethods.Time_of_Use;
			PauseState m_CurrentPauseState = PauseState.None;
			ManualResetEvent m_ClearDelay = new ManualResetEvent(false);
			bool m_UpdateLogWindowForBatteryData = true;

			// 2nd port for sending test transmissions only
			string m_SerPort2Name = Properties.Settings.Default.ComPort2;
			clsSerPortTools m_SerPort2;
		#endregion

		#region "Delegates"
		#endregion

		#region "Events"
			public event delDebugLogEnableChanged LogEnableChanged;
			public event delPauseEnableChanged PauseEnableChanged;
			public event delSerialPortStateChanged SerialPortStateChanged;
			public event delSerialPortDataReceived SerialPortDataReceived;
			public event delChargeRateDataReceived ChargeRateDataReceived;
			public event delPriceDataReceived PriceDataReceived;
			public event delDateReceived DateReceived;
			public event delSystemStateChanged SystemStateChanged;
			public event delSystemMessage SystemMessageUpdated;
			public event delChargeDataReceived ChargeDataReceived;
			public event delChargeEndTimeReceived ChargeEndTimeReceived;
			public event delChargeBeginTimeReceived ChargeStartTimeReceived;
			public event delBatteryDataReceived BatteryDataReceived;
			public event delSystemPaused SystemPaused;
			public event delChargeConfigDataReceived ChargeConfigDataReceived;
			public event del2847MsgReceived StdMsgReceived;
			public event delResetPlotsReceived ResetPlotsReceived;
		#endregion

		#region "Properties"
			public string Msg
			{
				get {return m_Msg;}
			}

			public bool DebugLogging
			{
				get { return m_DebugLoggingEnabled; }
				set
				{
					m_DebugLoggingEnabled = value;
					if (m_DebugLoggingEnabled)
					{
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Debug log enabled");
						clsLogTools.SetFileLogLevel(clsLogTools.LogLevels.DEBUG);
					}
					else
					{
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Debug log disabled");
						clsLogTools.SetFileLogLevel(clsLogTools.LogLevels.INFO);
					}
					if (LogEnableChanged != null) LogEnableChanged(m_DebugLoggingEnabled);
				}
			}

			public bool PauseEnable
			{
				get { return m_PauseEnabled; }
				set
				{
					m_PauseEnabled = value;
					if (m_PauseEnabled)
					{
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Pause enabled");
					}
					else clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Pause disabled");

					if (PauseEnableChanged != null) PauseEnableChanged(m_PauseEnabled);
				}
			}

			public string SerialPortName
			{
				get { return m_SerPortName; }
				set { m_SerPortName = value; }
			}

			public string SerialPort2Name
			{
				get { return m_SerPort2Name; }
				set { m_SerPort2Name = value; }
			}

			public bool SerialPort2Open
			{
				get { return IsPort2Open(); }
			}

			public double[] PriceArray
			{
				get { return m_PriceArray; }
				set { m_PriceArray = value; }
			}

			public ChargeMethods ChargeMethod
			{
				get { return m_ChargeMethod; }
				set { m_ChargeMethod = value; }
			}

			public SystemStates SystemState { get { return m_CurrentState; } }
		#endregion

		#region "Constructors"
			public clsMainProgram()
			{
				// Init price array
				m_PriceArray = new double[96];
				for (int indx = 0; indx < m_PriceArray.Length; indx++)
				{
					m_PriceArray[indx] = 0.0;
				}
			}	// End sub
		#endregion

		#region "Methods"
			/// <summary>
			/// Initializes class items that can't be done in constructor
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool InitApplication()
			{
				// Initialize logging
				if (!InitLogging()) return false;

				// Initialize pause setting
				this.PauseEnable = Properties.Settings.Default.PauseEnabled;

				// Initialize serial port
				if (m_SerPortName == "")
				{
					m_Msg = "Serial port name must be specified. Application will close";
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile,clsLogTools.LogLevels.ERROR,m_Msg);
					return false;
				}
				InitSerialPort();

				// Initialize serial port 2
				if (Properties.Settings.Default.UseTwoPorts)
				{
					if (m_SerPort2Name == "")
					{
						m_Msg = "Output serial port name must be specified. Application will close";
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, m_Msg);
						return false;
					}
					InitSerialPort2();
				}

				// Set initial state
				m_CurrentState = SystemStates.NotConnected;
				if (SystemStateChanged != null) SystemStateChanged(m_CurrentState);
				return true;
			}	// End sub

			/// <summary>
			/// Initializes logging
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			private bool InitLogging()
			{
				// Make sure a logging directory exists
				FileInfo fi = new FileInfo(System.Reflection.Assembly.GetExecutingAssembly().FullName);
				string programFolder = fi.DirectoryName;
				if (!File.Exists(Path.Combine(programFolder, "Logs")))
				{
					try
					{
						Directory.CreateDirectory(Path.Combine(programFolder, "Logs"));
					}
					catch (Exception ex)
					{
						m_Msg = "Exception creating log directory. Program will exit. Exception message = " + ex.Message;
						return false;
					}
				}

				// Set up the loggers
				string logFileName = Properties.Settings.Default.LogFileName;
				int debugLevel = Properties.Settings.Default.DebugLogLevel;
				clsLogTools.CreateFileLogger(logFileName, debugLevel);

				// Set initial log level based on config file
				if (debugLevel == 5)
				{
					// Debug logging enabled in config
					m_DebugLoggingEnabled = true;
				}
				else
				{
					// Debug logging disabled in config
					m_DebugLoggingEnabled = false;
				}
				if (LogEnableChanged != null) LogEnableChanged(m_DebugLoggingEnabled);

				// Make initial log entry
				string msg = "===== Starting PHEV_01, V" + System.Windows.Forms.Application.ProductVersion + " ===== ";
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, msg);

				return true;
			}	// End sub

			/// <summary>
			/// Initializes the serial port
			/// </summary>
			private void InitSerialPort()
			{
				clsSerialPortData portData = new clsSerialPortData();
				portData.Baudrate = Properties.Settings.Default.Baudrate;
				portData.Databits = Properties.Settings.Default.Databits;
				portData.HandshakeAsString = Properties.Settings.Default.Handshake;
				portData.ParityAsString = Properties.Settings.Default.Parity;
				portData.StopbitsAsString = Properties.Settings.Default.Stopbits;
				portData.PortName = m_SerPortName;

				m_SerPort = new clsSerPortTools(portData);
				m_SerPort.DataReceived += new delDataReceived(OnSerialPortDataReceived);
			}	// End sub

			private void InitSerialPort2()
			{
				clsSerialPortData portData = new clsSerialPortData();
				portData.Baudrate = Properties.Settings.Default.BaudrateComPort2;
				portData.Databits = Properties.Settings.Default.DatabitsComPort2;
				portData.HandshakeAsString = Properties.Settings.Default.HandshakeComPort2;
				portData.ParityAsString = Properties.Settings.Default.ParityComPort2;
				portData.StopbitsAsString = Properties.Settings.Default.StopbitsComPort2;
				portData.PortName = m_SerPort2Name;

				m_SerPort2 = new clsSerPortTools(portData);
				bool dummy = m_SerPort2.OpenPort();
			}	// End sub

			/// <summary>
			/// Opens the serial port
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool OpenPort()
			{
				bool result = m_SerPort.OpenPort();
				if (result)
				{
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Port " + m_SerPort.PortName + " opened");
					if (SerialPortStateChanged != null) SerialPortStateChanged(true, "Port " + m_SerPort.PortName + " opened");
					return true;
				}
				else
				{
					string errMsg = "Error opening port " + m_SerPort.PortName + ": " + m_SerPort.Msg;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, errMsg);
					if (SerialPortStateChanged != null) SerialPortStateChanged(false, errMsg);
					return false;
				}
			}	// End sub

			/// <summary>
			/// Closes a serial port
			/// </summary>
			public void ClosePort()
			{
				bool result = m_SerPort.ClosePort();
				if (result)
				{
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Port " + m_SerPort.PortName + " closed");
					if (SerialPortStateChanged != null) SerialPortStateChanged(false, m_SerPort.PortName + " closed");
					return;
				}
				else
				{
					string errMsg = "Error closing port " + m_SerPort.PortName + ": " + m_SerPort.Msg;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, errMsg);
					if (SerialPortStateChanged != null) SerialPortStateChanged(false, errMsg);
					return;
				}
			}	// End sub

			/// <summary>
			/// Sends board a request for battery data
			/// </summary>
			/// <returns></returns>
			public bool GetBatteryStatusFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.BATTERY_STATUS));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends board a request for charge data
			/// </summary>
			/// <returns></returns>
			public bool GetChargeStateFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.CHARGE_STATE));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to upload charge rate data from board
			/// </summary>
			/// <returns></returns>
			public bool GetChargeRateFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.RATE_SCHEDULE));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to retrieve price array from board
			/// </summary>
			/// <returns></returns>
			public bool GetPriceFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.PRICE_SCHEDULE));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Gets the VIN from the board
			/// </summary>
			public bool GetVinFromBoard()
			{
				System.Diagnostics.Debug.WriteLine("QueryVin: Thread name = " + System.Threading.Thread.CurrentThread.Name);

				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.VIN));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Gets the current state from the board
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool GetCurrentStateFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.STATE));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Gets the current value of the C= command from board
			/// </summary>
			/// <returns></returns>
			public bool GetCurrentChargeCommandFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.COMMAND));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to get actual charge start time from board
			/// </summary>
			/// <returns></returns>
			public bool GetActualChargeStartFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.ACTUAL_CHARGE_START_TIME));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to get the commanded charge end time from the board
			/// </summary>
			public bool GetCommandedChargeEndTimeFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.CHARGE_FINISH_COMMANDED));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to get current date/time from board
			/// </summary>
			public bool GetDateTimeFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.DATE));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to get actual charge finish time from board
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool GetActualChargeFinishTimeFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.ACTUAL_CHARGE_STOP_TIME));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends request for charge config data to board
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool GetChargeConfigFromBoard()
			{
				if (m_SerPort.PortOpen)
				{
					m_SerPort.SendMsg(clsMsgTools.CreateQueryMsg(clsMsgTools.QueryCodes.CHARGE_CONFIG));
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends a custom command to board
			/// </summary>
			/// <param name="cmd">Command to be sent</param>
			public bool SendCustomCmd(string cmd)
			{
				if (m_SerPort.PortOpen)
				{
					string msg = clsMsgTools.AddStartEndChars(cmd);
					if (m_SerPort.SendMsg(msg))
					{
						return true;
					}
					else
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends a price array to the board (Overload to used passed in array)
			/// </summary>
			/// <param name="priceArray">Input array of prices</param>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SendPriceArrayToBoard(double[] priceArray)
			{
				m_PriceArray = priceArray;
				return SendPriceArrayToBoard();
			}	// End sub

			/// <summary>
			/// Sends a price array to the board (Overload for using property)
			/// </summary>
			/// <param name="priceArray"></param>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SendPriceArrayToBoard()
			{
				if (m_SerPort.PortOpen)
				{
					SendStdMsgToHmi("P");

					string loadPriceCmd = clsMsgTools.CreatePriceUpdateMsg(m_PriceArray);
					System.Diagnostics.Debug.WriteLine(loadPriceCmd);
					if (!m_SerPort.SendMsg(loadPriceCmd))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
					else return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends commands to set date and commanded charge end time to board
			/// </summary>
			/// <returns>TRUE for success; otherwise FALSE</returns>
			public bool SetDate()
			{
				if (m_SerPort.PortOpen)
				{
					// Send current date
					string msg = clsMsgTools.CreateDateMessage();
					if (!m_SerPort.SendMsg(msg))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}

					// Wait for board to complete command
					System.Threading.Thread.Sleep(50);

					// Set charge completion to 6 AM next day
					DateTime currDate = DateTime.Now;
					currDate = currDate.AddDays(1.0);
					string currDateStr = currDate.ToString("MM/dd/yyyy ");
					currDateStr += "06:00:00";
					DateTime chgStopTime = DateTime.Parse(currDateStr);
					msg = clsMsgTools.CreateChargeCompleteTimeMessage(chgStopTime);
					if (m_SerPort.SendMsg(msg))
					{
						return true;
					}
					else
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends a new system state to the board
			/// </summary>
			/// <param name="newState">New state to send</param>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SetSystemState(SystemStates newState)
			{
				if (m_SerPort.PortOpen)
				{
					// Send current date
					string msg = clsMsgTools.CreateSetSystemStateMsg(newState);
					if (!m_SerPort.SendMsg(msg))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
					return true;
				}
				else
				{
					m_Msg = "Serial port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Resets the battery SOC data
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool ResetSoc()
			{
				if (m_SerPort.PortOpen)
				{
					// Send reset command
					string msg = clsMsgTools.CreateChargeModeMessage(0);
					if (!m_SerPort.SendMsg(msg))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
					return true;
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends command to set charge method (Overload using passed in method)
			/// </summary>
			/// <param name="chgMethod">Charge metod to be set</param>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SetChargeMethod(ChargeMethods chgMethod)
			{
				m_ChargeMethod = chgMethod;
				return SetChargeMethod();
			}	// End sub

			/// <summary>
			/// Sends command to set charge method (Overload using method set via property)
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SetChargeMethod()
			{
				if (m_SerPort.PortOpen)
				{
					// Send charge mode command
					string msg = clsMsgTools.CreateChargeModeMessage(m_ChargeMethod);
					if (!m_SerPort.SendMsg(msg))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
					else return true;
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sets the test mode based on config file
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SetTestMode(bool useTestMode)
			{
				if (m_SerPort.PortOpen)
				{
					// Send mode command
					string msg = clsMsgTools.CreateTestModeMessage(useTestMode);
					if (!m_SerPort.SendMsg(msg))
					{
						m_Msg = m_SerPort.Msg;
						return false;
					}
					else return true;
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Sends VIN to board
			/// </summary>
			/// <returns>TRUE for success; FALSE otherwise</returns>
			public bool SetVIN(string vin, int portNum)
			{
				clsSerPortTools tmpPort = null;

				if (portNum == 1)
				{
					tmpPort = m_SerPort;
				}
				else tmpPort = m_SerPort2;

				if (tmpPort.PortOpen)
				{
					// Send VIN command
					string msg = clsMsgTools.CreateVinMessage(vin);
					if (!tmpPort.SendMsg(msg))
					{
						m_Msg = tmpPort.Msg;
						return false;
					}
					else return true;
				}
				else
				{
					m_Msg = "Port not open";
					return false;
				}
			}	// End sub

			/// <summary>
			/// Continues the charge cycle currently in progress
			/// </summary>
			public void ContinueCharge()
			{
				switch (m_CurrentPauseState)
				{
					case PauseState.Send_Date_Time:
						// Send the current date and time to EVSE board
						if (!SetDate()) clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error sending date to EVSE: " + m_Msg);
						break;
					case PauseState.Send_Bound:
						// Send Y=3 to EVSE board
						if (!SetSystemState(SystemStates.Binding))
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error setting EVSE to state 3: " + m_Msg);
						break;
					case PauseState.Send_Mode:
						// Send price schedule and charge mode to board
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "ContinueCharge: Sending price and mode");
						SendPriceAndMode();
						break;
					default:
						// Do nothing
						break;
				}
			}	// End sub

			/// <summary>
			/// Tests if 2nd serial port is open
			/// </summary>
			/// <returns></returns>
			private bool IsPort2Open()
			{
				if (m_SerPort2 == null) return false;

				if (!m_SerPort2.PortOpen) return false;

				return true;
			}	// End sub

			/// <summary>
			/// Sends a message to the HMI for display on the log screen
			/// </summary>
			/// <param name="msgCode">First letter of input message</param>
			private void SendStdMsgToHmi(string msgCode)
			{
//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "SendStdMsgToHmi: Starting method");

				string msg = "";
				string direction = "Rcv";

				// First, check for state-based message
				switch (m_CurrentState)
				{
					case SystemStates.Connected:
						if (msgCode.ToLower() == "z") msg = "Vehicle ID, Use Case, Smart PEV Present, Customer Mode Preference";
						if (msgCode.ToLower() == "b") msg = "Usable Battery Energy, Energy Request";
						break;
					case SystemStates.Authenticating:
						if (msgCode.ToLower() == "b") msg = "Communications authenticated";
						break;
					case SystemStates.Binding:
						if (msgCode.ToLower() == "b") msg = "Request Scheduled Prices";
						break;
					case SystemStates.Precharge:
						if (msgCode.ToLower() == "e") msg = "Power Request";
						if (msgCode.ToLower() == "b") msg = "Time Charging to Start/End";
						break;
					case SystemStates.ChargeDelay:
						if (msgCode.ToLower() == "r") msg = "Power Schedule";
						if (msgCode.ToLower() == "b") msg = "Power Available";
						break;
					case SystemStates.Charging:
						if (msgCode.ToLower() == "s") msg = "Actual Start Time";
						if (msgCode.ToLower() == "b") msg = "Energy Delivered";
						break;
					case SystemStates.ChargeComplete:
						if (msgCode.ToLower() == "cc") msg = "Energy Delivered";
						break;
					default:
						// Do nothing
						break;
				}

				// Check for Price rate change message
				if (msgCode.ToLower() == "p")
				{
					msg = "Price for Rate Time Period";
					direction = "Snd";
				}

//				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "SendStdMsgToHmi: msg=" + msg);

				// If a legit message
				if (msg != "")
				{
					if (StdMsgReceived != null) StdMsgReceived(direction, msg);
				}
			}	// End sub
		#endregion

		#region "Received data handling methods"
			/// <summary>
			/// Handles receipt of charge rate data from board
			/// </summary>
			/// <param name="data">String containing charge rates</param>
			private void OnRateDataReceived(string data)
			{
				double[] rateData = clsMsgTools.MakeRateArrayFromMsg(data);
				if (rateData == null)
				{
					string tmpStr = "Problem converting charge rate data: " + clsMsgTools.Msg;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, tmpStr);
					if (SystemMessageUpdated != null) SystemMessageUpdated(tmpStr);
					return;
				}

				SendStdMsgToHmi("R");
				if (ChargeRateDataReceived != null) ChargeRateDataReceived(rateData);
			}	// End sub

			/// <summary>
			/// Handles receipt of price data array from board
			/// </summary>
			/// <param name="data">String containing price data</param>
			private void OnPriceDataReceived(string data)
			{
				double[] priceData = clsMsgTools.MakeCostArrayFromMsg(data);
				if (priceData == null)
				{
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Null received for price data");
					return;
				}

				if (PriceDataReceived != null) PriceDataReceived(priceData);
			}	// End sub

			/// <summary>
			/// Handles receipt of current date from board
			/// </summary>
			/// <param name="data">Current date string</param>
			private void OnDateReceived(string data)
			{
				if (DateReceived != null) DateReceived(data);
			}	// End sub

			/// <summary>
			/// Handles receipt of charge config data from board
			/// </summary>
			/// <param name="data">Charge config data string</param>
			private void OnChargeConfigDataReceived(string data)
			{
				// Parse the input string
				clsChargeConfigData configData = clsMsgTools.GetChargeConfigDataFromMessage(data);
				if (configData == null)
				{
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, clsMsgTools.Msg);
					if (SystemMessageUpdated != null) SystemMessageUpdated(clsMsgTools.Msg);
					return;
				}

				// Forward data to UI
				if (ChargeConfigDataReceived != null) ChargeConfigDataReceived(configData);
			}	// End sub

			/// <summary>
			/// Handles receipt of system state from board
			/// </summary>
			/// <param name="data">State string</param>
			private void OnSystemStateReceived(string data)
			{
				// Convert input to a state value
				SystemStates inputState = SystemStates.InvalidState;
				string tmpStr = data.Replace("Y=", "");
				try
				{
					inputState = clsMsgTools.ConvertShortToSystemState(short.Parse(tmpStr));
					if (inputState == SystemStates.InvalidState)
					{
						m_Msg = "Invalid state value received: " + data;
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, m_Msg);
						return;
					}
				}
				catch (Exception ex)
				{
					m_Msg = "Exception converting input message " + data + " to system state value. Message = " + ex.Message;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile,clsLogTools.LogLevels.ERROR,m_Msg);
				}

				// If recevied state is same as current state, do nothing
				if (inputState == m_CurrentState) return;

				switch (inputState)
				{
					case SystemStates.NotConnected:
						// Just update the state and displays
						m_CurrentState = inputState;
						m_UpdateLogWindowForBatteryData = true;
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile,clsLogTools.LogLevels.INFO,"New state = \"Not Connected\"");
						if (SystemStateChanged != null) SystemStateChanged(inputState);
						break;
					case SystemStates.Connected:
						// Update state and displays, send date/time to EVSE
						//TODO: Clear displays?
						m_CurrentState = inputState;
						m_UpdateLogWindowForBatteryData = true;
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile,clsLogTools.LogLevels.INFO,"New state = \"Connected\"");
						if (SystemStateChanged != null) SystemStateChanged(inputState);

						// Send test mode to EVSE board
						if (!SetTestMode(Properties.Settings.Default.TestMode)) clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error sending date to EVSE: " + m_Msg);
						
						// If pause enabled, set pause state and wait
						if (m_PauseEnabled)
						{
							// Set current pause state
							clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Pausing after connection");
							m_CurrentPauseState = PauseState.Send_Date_Time;
							if (SystemPaused != null) SystemPaused();
						}
						else
						{
							// Send date/time to EVSE board
							if (!SetDate()) clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error sending date to EVSE: " + m_Msg);
						}
						break;
					case SystemStates.Precharge:
						m_UpdateLogWindowForBatteryData = true;
						// Update displays
						m_CurrentState = inputState;
						if (SystemStateChanged != null) SystemStateChanged(inputState);
						break;
					case SystemStates.ChargeDelay:
						m_UpdateLogWindowForBatteryData = true;
						// Update displays
						m_CurrentState = inputState;
						if (SystemStateChanged != null) SystemStateChanged(inputState);
						break;
					case SystemStates.Charging:
						m_UpdateLogWindowForBatteryData = true;
						// Update displays
						m_CurrentState = inputState;
						if (SystemStateChanged != null) SystemStateChanged(inputState);
						break;
					case SystemStates.ChargeComplete:
						m_UpdateLogWindowForBatteryData = true;
						// Update displays
						m_CurrentState = inputState;
						SendStdMsgToHmi("CC");
						if (SystemStateChanged != null) SystemStateChanged(inputState);
						// Change to state 8, send to EVSE
						m_CurrentState = SystemStates.Billing;
						if (SystemStateChanged != null) SystemStateChanged(SystemStates.Billing);
						if (!SetSystemState(SystemStates.Billing)) 
									clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error setting EVSE to state 8: " + m_Msg);
						// Send status update to HMI
						if (SystemMessageUpdated != null) SystemMessageUpdated("Sending billing data to utility");
						// Delay to fake billing cycle
						System.Threading.Thread.Sleep(5000);
						// Change status at HMI to billing complete
						if (SystemMessageUpdated != null) SystemMessageUpdated("Billing complete");
						break;
				}
			}	// End sub

			/// <summary>
			/// Handles receipt of user data string
			/// </summary>
			/// <param name="data">String received from board</param>
			private void OnUserDataReceived(string data)
			{
				SendStdMsgToHmi("Z");

				// Strip off the "Z="
				string tmpData = data.Replace("Z=", "");

				//TODO: Parse statement someday
				// If current state = Bound, ignore because we've already taken action
				if (m_CurrentState == SystemStates.Binding) return;

				// Set new state
				m_CurrentState = SystemStates.Authenticating;
				if (SystemStateChanged != null) SystemStateChanged(SystemStates.Authenticating);
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "New state = \"Authenticated\"");

				// Fake connecting to utility
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "Authenticating with utility");
				if (SystemMessageUpdated != null) SystemMessageUpdated("Authenticating with utility");

				// Take a nap to convince user we're doing something
				if (m_ClearDelay.WaitOne(5000))
				{
					// Program is exiting, so just return
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "OnUserDataReceived: Exiting method due to program shutdown");
					return;
				}	
			
				// Fake receipt of authentication from utility
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "Authentication received from utility");
				if (SystemMessageUpdated != null) SystemMessageUpdated("Authentication received from utility");

				// Set state to Bound and tell EVSE
				m_CurrentState = SystemStates.Binding;
				if (SystemStateChanged != null) SystemStateChanged(SystemStates.Binding);
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "New state = \"Bound\"");

				// Check to see if charge process should pause
				if (m_PauseEnabled)
				{
					// Set current pause state
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Pausing after authorization");
					m_CurrentPauseState = PauseState.Send_Bound;
					if (SystemPaused != null) SystemPaused();
				}
				else
				{
					// Go ahead and send bound state to EVSE board
					if (!SetSystemState(SystemStates.Binding))
						clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, "Error setting EVSE to state 3: " + m_Msg);
				}
			}	// End sub

			/// <summary>
			/// Handles receipt of energy requirement for charging
			/// </summary>
			/// <param name="data">Energy requirement string</param>
			private void OnEnergyRequirementReceived(string data)
			{
				// Parse the input message
				clsEnergyRequestData energyData = clsMsgTools.GetEnergyDataFromMessage(data);
				if (energyData == null)
				{
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, clsMsgTools.Msg);
					if (SystemMessageUpdated != null) SystemMessageUpdated(clsMsgTools.Msg);
					return;
				}
				
				// Update log viewer
				SendStdMsgToHmi("E");

				// Update display
				string tmpStr = "Received energy request for " + energyData.KiloWattHours.ToString("###0.0") + " kWh";
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, tmpStr);
				if (SystemMessageUpdated != null) SystemMessageUpdated("Energy request received");

				// Fake sending request to utility
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Sending energy request to utility");
				if (SystemMessageUpdated != null) SystemMessageUpdated("Sending energy request to utility");

				// Wait for fake utility response
				if (m_ClearDelay.WaitOne(5000))
				{
					// Program is exiting, so just return
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "OnEnergyRequirementReceived: Exiting method due to program shutdown");
					return;
				}	

				// Fake receipt of confirmation from utility
				if (SystemMessageUpdated != null) SystemMessageUpdated("Utility accepted energy request");
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Utility accepted energy request");

				// Check to see if charge process should pause
				if (m_PauseEnabled)
				{
					// Set current pause state
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.INFO, "Pausing after energy request response received");
					m_CurrentPauseState = PauseState.Send_Mode;
					if (SystemPaused != null) SystemPaused();
				}
				else
				{
					// Go ahead and send P/E schedule, charge mode to EVSE board
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "OnEnergyRequirementReceived: Sending price and mode");
					SendPriceAndMode();
				}
			}	// End sub

			/// <summary>
			/// Sends price schedule and current charge mode to board
			/// </summary>
			private void SendPriceAndMode()
			{
				// Send price schedule to board
				if (!SendPriceArrayToBoard())
				{
					m_Msg = "Error sending price array to board: " + m_Msg;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, m_Msg);
					if (SystemMessageUpdated != null) SystemMessageUpdated(m_Msg);
				}

				// Pause for board response, if any
				System.Threading.Thread.Sleep(50);

				// Send the current charge mode
				if (!SetChargeMethod())
				{
					m_Msg = "Error setting charge method: " + m_Msg;
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, m_Msg);
					if (SystemMessageUpdated != null) SystemMessageUpdated(m_Msg);
				}
			}	// End sub

			/// <summary>
			/// Handles receipt of charge data
			/// </summary>
			/// <param name="data">Input data string</param>
			private void OnChargingDataReceived(string data)
			{
				// Parse the message
				clsChargeData chargeData = clsMsgTools.GetChargeDataFromMsg(data);
				if (chargeData == null)
				{
					// There was a problem
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, clsMsgTools.Msg);
					return;
				}

				// Forward the data
				if (ChargeDataReceived != null) ChargeDataReceived(chargeData);
			}	// End sub

			/// <summary>
			/// Handles receipt of battery data
			/// </summary>
			/// <param name="data">Input data string</param>
			private void OnBatteryDataReceived(string data)
			{
				// Parse the message
				clsBatteryData battData = clsMsgTools.GetBatteryDataFromMsg(data);

				if (battData == null)
				{
					// There was a problem
					clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.ERROR, clsMsgTools.Msg);
					return;
				}

				// Forward the data
				if (m_UpdateLogWindowForBatteryData)
				{
					m_UpdateLogWindowForBatteryData = false;
					SendStdMsgToHmi("B");
				}
				if (BatteryDataReceived != null) BatteryDataReceived(battData);
			}	// End sub

			/// <summary>
			/// Handles receipt of commanded charge end time
			/// </summary>
			/// <param name="data">Input string from board</param>
			private void OnCommandedChargeEndTimeReceived(string data)
			{
				if (ChargeEndTimeReceived != null) ChargeEndTimeReceived(data.Replace("M=", ""));
			}	// End sub

			/// <summary>
			/// Handles receipt of charge start time
			/// </summary>
			/// <param name="data"></param>
			private void OnChargeBeginTimeReceived(string data)
			{
				SendStdMsgToHmi("S");
				if (ChargeStartTimeReceived != null) ChargeStartTimeReceived(data.Replace("S=", ""));
			}	// End sub

			/// <summary>
			/// Handles receipt of VIN and associated data
			/// </summary>
			/// <param name="data">Incoming message string</param>
			private void OnVehicleDataReceived(string data)
			{
				SendStdMsgToHmi("V");
			}	// End sub

			/// <summary>
			/// Handles receipt of command to reset plots
			/// </summary>
			private void OnResetPlotsReceived()
			{
				if (ResetPlotsReceived != null) ResetPlotsReceived();
			}	// End sub
		#endregion

		#region "Event handlers"
			/// <summary>
			/// Handles receipt of data at serial port
			/// </summary>
			/// <param name="data">received data</param>
			void OnSerialPortDataReceived(string data)
			{
//				if (data.Contains("Y=")) OnSystemStateReceived(data);
//				if (data.Contains("P=")) OnPriceDataReceived(data);
//				if (data.Contains("R=")) OnRateDataReceived(data);
//				if (data.Contains("M=")) OnCommandedChargeEndTimeReceived(data);
				if (data.Contains("X=")) OnChargingDataReceived(data);
//				if (data.Contains("D=")) OnDateReceived(data);
//				if (data.Contains("Z=")) OnUserDataReceived(data);
//				if (data.Contains("S=")) OnChargeBeginTimeReceived(data);
//				if (data.Contains("E=")) OnEnergyRequirementReceived(data);
//				if (data.Contains("B=")) OnBatteryDataReceived(data);
//				if (data.Contains("O=")) OnChargeConfigDataReceived(data);
//				if (data.Contains("V=")) OnVehicleDataReceived(data);
				if (data.Contains("Q=")) OnResetPlotsReceived();

				if (SerialPortDataReceived != null) SerialPortDataReceived(data);
			}	// End sub
		#endregion

		#region IDisposable Members
			public void Dispose()
			{
				clsLogTools.WriteLog(clsLogTools.LoggerTypes.LogFile, clsLogTools.LogLevels.DEBUG, "clsMainProgram.Dispose: Calling m_SerPort.Dispose()");

				// Release any waiting delays
				m_ClearDelay.Set();

				if (m_SerPort != null) m_SerPort.Dispose();
				m_SerPort = null;

				if (m_SerPort2 != null)
				{
					m_SerPort2.Dispose();
					m_SerPort2 = null;
				}
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
