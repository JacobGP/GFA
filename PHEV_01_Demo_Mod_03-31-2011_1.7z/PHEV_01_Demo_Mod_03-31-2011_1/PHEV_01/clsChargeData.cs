﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 09/20/2010
//
// Last modified 09/20/2010
//						03-21-2011 (DAC) - Modified units conversion for demo purposes
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	public class clsChargeData
	{
		//*********************************************************************************************************
		// Holds data for battery charge
		//**********************************************************************************************************

		#region "Constants"
			const double FREQ_CONV_CONST = 1.25e6 * 256;
			const double COST_CONV_CONST = 1000 * 3600 * 100;	// 1000w/kW, 3600 sec/hr, cents/$
		#endregion

		#region "Class variables"
			long m_Freq = 0;
			long m_Ave_Freq = 0;
			long m_TotalWattSec = 0;
			long m_TotalCost = 0;
			double m_ChargeAmps = 0;
		#endregion

		#region "Properties"
			public long FreqAsLong
			{
				get { return m_Freq; }
				set { m_Freq = value; }
			}

			public long AveFreqAsLong
			{
				get { return m_Ave_Freq; }
				set { m_Ave_Freq = value; }
			}

			public double FreqAsDouble { get { return ConvertFreq(m_Freq); } }

			public double AveFreqAsDouble { get { return ConvertFreq(m_Ave_Freq); } }

			public double ChargeAmps
			{
				get {return m_ChargeAmps / 5;}	// this actually gives kW, assuming a 200V charging voltage for demo
				set { m_ChargeAmps = (double)value; }
			}

			public int SOC { get; set; }

			public long WattSecAsLong
			{
				get { return m_TotalWattSec; }
				set { m_TotalWattSec = value; }
			}

			public double KWhrAsDouble { get { return ConvertEnergy(m_TotalWattSec); } }

			public long TotalCostAsLong
			{
				get { return m_TotalCost; }
				set { m_TotalCost = value; }
			}

			public double TotalCostAsDouble { get { return m_TotalCost / COST_CONV_CONST; } }

			public string CurrDateTime { get; set; }
		#endregion

		#region "Methods"
			/// <summary>
			/// Converts LONG freq read from board to floating-point frequency
			/// </summary>
			/// <param name="inpFreq">Input frequency</param>
			/// <returns>Calculated floating-point frequency</returns>
			private double ConvertFreq(long inpFreq)
			{
				return FREQ_CONV_CONST / (double)inpFreq;
			}	// End sub

			/// <summary>
			/// Converts energy in Watt-seconds to kWh
			/// </summary>
			/// <param name="inpWattSec">Input energy in Watt-sec</param>
			/// <returns>kWh equivalent</returns>
			private double ConvertEnergy(long inpWattSec)
			{
				// Actually returns state of charge in % for demo
				return ((double)inpWattSec * 100) / (1000 * 3600 * 4); // 1000 W/kW, 3600 sec/hr. 100%/4 kWh
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
