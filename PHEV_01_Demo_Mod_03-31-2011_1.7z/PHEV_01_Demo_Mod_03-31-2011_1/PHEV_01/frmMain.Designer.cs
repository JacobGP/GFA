﻿namespace PHEV_01
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabFrequency = new System.Windows.Forms.TabPage();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.grphFreqChart = new ZedGraph.ZedGraphControl();
			this.grphPwrChart = new ZedGraph.ZedGraphControl();
			this.tabOptions = new System.Windows.Forms.TabPage();
			this.panel6 = new System.Windows.Forms.Panel();
			this.btnResetPlots = new System.Windows.Forms.Button();
			this.panel5 = new System.Windows.Forms.Panel();
			this.lblPauseStatus = new System.Windows.Forms.Label();
			this.btnPauseControl = new System.Windows.Forms.Button();
			this.panel4 = new System.Windows.Forms.Panel();
			this.lblLogStatus = new System.Windows.Forms.Label();
			this.btnDebugLogControl = new System.Windows.Forms.Button();
			this.tabTest2 = new System.Windows.Forms.TabPage();
			this.panel3 = new System.Windows.Forms.Panel();
			this.rbPriceProfile4 = new System.Windows.Forms.RadioButton();
			this.rbPriceProfile3 = new System.Windows.Forms.RadioButton();
			this.rbPriceProfile2 = new System.Windows.Forms.RadioButton();
			this.label4 = new System.Windows.Forms.Label();
			this.rbPriceProfile1 = new System.Windows.Forms.RadioButton();
			this.label3 = new System.Windows.Forms.Label();
			this.txtRcxData = new System.Windows.Forms.TextBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnEnableRefresh = new System.Windows.Forms.Button();
			this.btnChargeData = new System.Windows.Forms.Button();
			this.btnStateRequest = new System.Windows.Forms.Button();
			this.btnCustomCmd = new System.Windows.Forms.Button();
			this.txtCustomCmd = new System.Windows.Forms.TextBox();
			this.btnResetSoc = new System.Windows.Forms.Button();
			this.btnLoadPrices = new System.Windows.Forms.Button();
			this.btnSetDate = new System.Windows.Forms.Button();
			this.btnChargeCommanded = new System.Windows.Forms.Button();
			this.btnPrice = new System.Windows.Forms.Button();
			this.btnVin = new System.Windows.Forms.Button();
			this.btnRate = new System.Windows.Forms.Button();
			this.btnActualChargeFinishTime = new System.Windows.Forms.Button();
			this.btnActualChargeStartTime = new System.Windows.Forms.Button();
			this.btnDate = new System.Windows.Forms.Button();
			this.btnCommand = new System.Windows.Forms.Button();
			this.btnBattData = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnClosePort = new System.Windows.Forms.Button();
			this.btnOpenPort = new System.Windows.Forms.Button();
			this.txtPortStatus = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.tabControl1.SuspendLayout();
			this.tabFrequency.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			this.tabOptions.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel4.SuspendLayout();
			this.tabTest2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
							| System.Windows.Forms.AnchorStyles.Left)
							| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabFrequency);
			this.tabControl1.Controls.Add(this.tabOptions);
			this.tabControl1.Controls.Add(this.tabTest2);
			this.tabControl1.ItemSize = new System.Drawing.Size(55, 30);
			this.tabControl1.Location = new System.Drawing.Point(12, 0);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1240, 870);
			this.tabControl1.TabIndex = 0;
			// 
			// tabFrequency
			// 
			this.tabFrequency.Controls.Add(this.tableLayoutPanel1);
			this.tabFrequency.Location = new System.Drawing.Point(4, 34);
			this.tabFrequency.Name = "tabFrequency";
			this.tabFrequency.Size = new System.Drawing.Size(1232, 832);
			this.tabFrequency.TabIndex = 5;
			this.tabFrequency.Text = "Frequency";
			this.tabFrequency.UseVisualStyleBackColor = true;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
							| System.Windows.Forms.AnchorStyles.Left)
							| System.Windows.Forms.AnchorStyles.Right)));
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Controls.Add(this.grphFreqChart, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.grphPwrChart, 0, 1);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 2;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(1229, 829);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// grphFreqChart
			// 
			this.grphFreqChart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
							| System.Windows.Forms.AnchorStyles.Left)
							| System.Windows.Forms.AnchorStyles.Right)));
			this.grphFreqChart.Location = new System.Drawing.Point(3, 3);
			this.grphFreqChart.Name = "grphFreqChart";
			this.grphFreqChart.ScrollGrace = 0D;
			this.grphFreqChart.ScrollMaxX = 0D;
			this.grphFreqChart.ScrollMaxY = 0D;
			this.grphFreqChart.ScrollMaxY2 = 0D;
			this.grphFreqChart.ScrollMinX = 0D;
			this.grphFreqChart.ScrollMinY = 0D;
			this.grphFreqChart.ScrollMinY2 = 0D;
			this.grphFreqChart.Size = new System.Drawing.Size(1223, 408);
			this.grphFreqChart.TabIndex = 9;
			// 
			// grphPwrChart
			// 
			this.grphPwrChart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
							| System.Windows.Forms.AnchorStyles.Left)
							| System.Windows.Forms.AnchorStyles.Right)));
			this.grphPwrChart.Location = new System.Drawing.Point(3, 417);
			this.grphPwrChart.Name = "grphPwrChart";
			this.grphPwrChart.ScrollGrace = 0D;
			this.grphPwrChart.ScrollMaxX = 0D;
			this.grphPwrChart.ScrollMaxY = 0D;
			this.grphPwrChart.ScrollMaxY2 = 0D;
			this.grphPwrChart.ScrollMinX = 0D;
			this.grphPwrChart.ScrollMinY = 0D;
			this.grphPwrChart.ScrollMinY2 = 0D;
			this.grphPwrChart.Size = new System.Drawing.Size(1223, 409);
			this.grphPwrChart.TabIndex = 10;
			// 
			// tabOptions
			// 
			this.tabOptions.Controls.Add(this.panel6);
			this.tabOptions.Controls.Add(this.panel5);
			this.tabOptions.Controls.Add(this.panel4);
			this.tabOptions.Location = new System.Drawing.Point(4, 34);
			this.tabOptions.Name = "tabOptions";
			this.tabOptions.Size = new System.Drawing.Size(1232, 832);
			this.tabOptions.TabIndex = 4;
			this.tabOptions.Text = "Options";
			this.tabOptions.UseVisualStyleBackColor = true;
			// 
			// panel6
			// 
			this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel6.Controls.Add(this.btnResetPlots);
			this.panel6.Location = new System.Drawing.Point(217, 27);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(155, 115);
			this.panel6.TabIndex = 5;
			// 
			// btnResetPlots
			// 
			this.btnResetPlots.Location = new System.Drawing.Point(22, 12);
			this.btnResetPlots.Name = "btnResetPlots";
			this.btnResetPlots.Size = new System.Drawing.Size(112, 41);
			this.btnResetPlots.TabIndex = 4;
			this.btnResetPlots.Text = "Reset Plots";
			this.btnResetPlots.UseVisualStyleBackColor = true;
			this.btnResetPlots.Click += new System.EventHandler(this.btnResetPlots_Click);
			// 
			// panel5
			// 
			this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel5.Controls.Add(this.lblPauseStatus);
			this.panel5.Controls.Add(this.btnPauseControl);
			this.panel5.Location = new System.Drawing.Point(28, 182);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(155, 115);
			this.panel5.TabIndex = 4;
			// 
			// lblPauseStatus
			// 
			this.lblPauseStatus.Location = new System.Drawing.Point(19, 58);
			this.lblPauseStatus.Name = "lblPauseStatus";
			this.lblPauseStatus.Size = new System.Drawing.Size(112, 44);
			this.lblPauseStatus.TabIndex = 4;
			this.lblPauseStatus.Text = "Temp Text";
			this.lblPauseStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnPauseControl
			// 
			this.btnPauseControl.Location = new System.Drawing.Point(19, 14);
			this.btnPauseControl.Name = "btnPauseControl";
			this.btnPauseControl.Size = new System.Drawing.Size(112, 41);
			this.btnPauseControl.TabIndex = 3;
			this.btnPauseControl.Text = "Enable Pause";
			this.btnPauseControl.UseVisualStyleBackColor = true;
			this.btnPauseControl.Click += new System.EventHandler(this.btnPauseControl_Click);
			// 
			// panel4
			// 
			this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel4.Controls.Add(this.lblLogStatus);
			this.panel4.Controls.Add(this.btnDebugLogControl);
			this.panel4.Location = new System.Drawing.Point(28, 24);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(155, 115);
			this.panel4.TabIndex = 3;
			// 
			// lblLogStatus
			// 
			this.lblLogStatus.Location = new System.Drawing.Point(19, 58);
			this.lblLogStatus.Name = "lblLogStatus";
			this.lblLogStatus.Size = new System.Drawing.Size(112, 44);
			this.lblLogStatus.TabIndex = 4;
			this.lblLogStatus.Text = "Temp Text";
			this.lblLogStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnDebugLogControl
			// 
			this.btnDebugLogControl.Location = new System.Drawing.Point(19, 14);
			this.btnDebugLogControl.Name = "btnDebugLogControl";
			this.btnDebugLogControl.Size = new System.Drawing.Size(112, 41);
			this.btnDebugLogControl.TabIndex = 3;
			this.btnDebugLogControl.Text = "Enable Debug Log";
			this.btnDebugLogControl.UseVisualStyleBackColor = true;
			this.btnDebugLogControl.Click += new System.EventHandler(this.btnDebugLogControl_Click);
			// 
			// tabTest2
			// 
			this.tabTest2.Controls.Add(this.panel3);
			this.tabTest2.Controls.Add(this.label3);
			this.tabTest2.Controls.Add(this.txtRcxData);
			this.tabTest2.Controls.Add(this.panel2);
			this.tabTest2.Controls.Add(this.panel1);
			this.tabTest2.Controls.Add(this.txtPortStatus);
			this.tabTest2.Controls.Add(this.label2);
			this.tabTest2.Location = new System.Drawing.Point(4, 34);
			this.tabTest2.Name = "tabTest2";
			this.tabTest2.Size = new System.Drawing.Size(1232, 832);
			this.tabTest2.TabIndex = 3;
			this.tabTest2.Text = "Test";
			this.tabTest2.UseVisualStyleBackColor = true;
			// 
			// panel3
			// 
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.rbPriceProfile4);
			this.panel3.Controls.Add(this.rbPriceProfile3);
			this.panel3.Controls.Add(this.rbPriceProfile2);
			this.panel3.Controls.Add(this.label4);
			this.panel3.Controls.Add(this.rbPriceProfile1);
			this.panel3.Location = new System.Drawing.Point(15, 153);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(100, 171);
			this.panel3.TabIndex = 15;
			// 
			// rbPriceProfile4
			// 
			this.rbPriceProfile4.AutoSize = true;
			this.rbPriceProfile4.Location = new System.Drawing.Point(12, 98);
			this.rbPriceProfile4.Name = "rbPriceProfile4";
			this.rbPriceProfile4.Size = new System.Drawing.Size(63, 17);
			this.rbPriceProfile4.TabIndex = 4;
			this.rbPriceProfile4.Text = "Profile 4";
			this.rbPriceProfile4.UseVisualStyleBackColor = true;
			this.rbPriceProfile4.CheckedChanged += new System.EventHandler(this.rbPriceProfile4_CheckedChanged);
			// 
			// rbPriceProfile3
			// 
			this.rbPriceProfile3.AutoSize = true;
			this.rbPriceProfile3.Location = new System.Drawing.Point(12, 74);
			this.rbPriceProfile3.Name = "rbPriceProfile3";
			this.rbPriceProfile3.Size = new System.Drawing.Size(63, 17);
			this.rbPriceProfile3.TabIndex = 3;
			this.rbPriceProfile3.Text = "Profile 3";
			this.rbPriceProfile3.UseVisualStyleBackColor = true;
			this.rbPriceProfile3.CheckedChanged += new System.EventHandler(this.rbPriceProfile3_CheckedChanged);
			// 
			// rbPriceProfile2
			// 
			this.rbPriceProfile2.AutoSize = true;
			this.rbPriceProfile2.Location = new System.Drawing.Point(12, 51);
			this.rbPriceProfile2.Name = "rbPriceProfile2";
			this.rbPriceProfile2.Size = new System.Drawing.Size(63, 17);
			this.rbPriceProfile2.TabIndex = 2;
			this.rbPriceProfile2.Text = "Profile 2";
			this.rbPriceProfile2.UseVisualStyleBackColor = true;
			this.rbPriceProfile2.CheckedChanged += new System.EventHandler(this.rbPriceProfile2_CheckedChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(9, 8);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(68, 13);
			this.label4.TabIndex = 1;
			this.label4.Text = "Price Profiles";
			// 
			// rbPriceProfile1
			// 
			this.rbPriceProfile1.AutoSize = true;
			this.rbPriceProfile1.Checked = true;
			this.rbPriceProfile1.Location = new System.Drawing.Point(12, 27);
			this.rbPriceProfile1.Name = "rbPriceProfile1";
			this.rbPriceProfile1.Size = new System.Drawing.Size(63, 17);
			this.rbPriceProfile1.TabIndex = 0;
			this.rbPriceProfile1.TabStop = true;
			this.rbPriceProfile1.Text = "Profile 1";
			this.rbPriceProfile1.UseVisualStyleBackColor = true;
			this.rbPriceProfile1.CheckedChanged += new System.EventHandler(this.rbPriceProfile1_CheckedChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(442, 133);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(33, 13);
			this.label3.TabIndex = 14;
			this.label3.Text = "Data:";
			// 
			// txtRcxData
			// 
			this.txtRcxData.Location = new System.Drawing.Point(498, 133);
			this.txtRcxData.Multiline = true;
			this.txtRcxData.Name = "txtRcxData";
			this.txtRcxData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtRcxData.Size = new System.Drawing.Size(240, 191);
			this.txtRcxData.TabIndex = 13;
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.btnEnableRefresh);
			this.panel2.Controls.Add(this.btnChargeData);
			this.panel2.Controls.Add(this.btnStateRequest);
			this.panel2.Controls.Add(this.btnCustomCmd);
			this.panel2.Controls.Add(this.txtCustomCmd);
			this.panel2.Controls.Add(this.btnResetSoc);
			this.panel2.Controls.Add(this.btnLoadPrices);
			this.panel2.Controls.Add(this.btnSetDate);
			this.panel2.Controls.Add(this.btnChargeCommanded);
			this.panel2.Controls.Add(this.btnPrice);
			this.panel2.Controls.Add(this.btnVin);
			this.panel2.Controls.Add(this.btnRate);
			this.panel2.Controls.Add(this.btnActualChargeFinishTime);
			this.panel2.Controls.Add(this.btnActualChargeStartTime);
			this.panel2.Controls.Add(this.btnDate);
			this.panel2.Controls.Add(this.btnCommand);
			this.panel2.Controls.Add(this.btnBattData);
			this.panel2.Location = new System.Drawing.Point(121, 30);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(286, 294);
			this.panel2.TabIndex = 12;
			// 
			// btnEnableRefresh
			// 
			this.btnEnableRefresh.Location = new System.Drawing.Point(195, 56);
			this.btnEnableRefresh.Name = "btnEnableRefresh";
			this.btnEnableRefresh.Size = new System.Drawing.Size(75, 41);
			this.btnEnableRefresh.TabIndex = 19;
			this.btnEnableRefresh.Text = "Disable Refresh";
			this.btnEnableRefresh.UseVisualStyleBackColor = true;
			this.btnEnableRefresh.Click += new System.EventHandler(this.btnEnableRefresh_Click);
			// 
			// btnChargeData
			// 
			this.btnChargeData.Location = new System.Drawing.Point(14, 56);
			this.btnChargeData.Name = "btnChargeData";
			this.btnChargeData.Size = new System.Drawing.Size(75, 41);
			this.btnChargeData.TabIndex = 18;
			this.btnChargeData.Text = "Chg Data?";
			this.btnChargeData.UseVisualStyleBackColor = true;
			this.btnChargeData.Click += new System.EventHandler(this.btnChargeData_Click);
			// 
			// btnStateRequest
			// 
			this.btnStateRequest.Location = new System.Drawing.Point(104, 150);
			this.btnStateRequest.Name = "btnStateRequest";
			this.btnStateRequest.Size = new System.Drawing.Size(75, 41);
			this.btnStateRequest.TabIndex = 17;
			this.btnStateRequest.Text = "State?";
			this.btnStateRequest.UseVisualStyleBackColor = true;
			this.btnStateRequest.Click += new System.EventHandler(this.btnStateRequest_Click);
			// 
			// btnCustomCmd
			// 
			this.btnCustomCmd.Location = new System.Drawing.Point(14, 249);
			this.btnCustomCmd.Name = "btnCustomCmd";
			this.btnCustomCmd.Size = new System.Drawing.Size(75, 31);
			this.btnCustomCmd.TabIndex = 16;
			this.btnCustomCmd.Text = "Custom Cmd";
			this.btnCustomCmd.UseVisualStyleBackColor = true;
			this.btnCustomCmd.Click += new System.EventHandler(this.btnCustomCmd_Click);
			// 
			// txtCustomCmd
			// 
			this.txtCustomCmd.Location = new System.Drawing.Point(104, 255);
			this.txtCustomCmd.Name = "txtCustomCmd";
			this.txtCustomCmd.Size = new System.Drawing.Size(166, 20);
			this.txtCustomCmd.TabIndex = 15;
			// 
			// btnResetSoc
			// 
			this.btnResetSoc.Location = new System.Drawing.Point(195, 150);
			this.btnResetSoc.Name = "btnResetSoc";
			this.btnResetSoc.Size = new System.Drawing.Size(75, 41);
			this.btnResetSoc.TabIndex = 14;
			this.btnResetSoc.Text = "Reset SOC";
			this.btnResetSoc.UseVisualStyleBackColor = true;
			this.btnResetSoc.Click += new System.EventHandler(this.btnResetSoc_Click);
			// 
			// btnLoadPrices
			// 
			this.btnLoadPrices.Location = new System.Drawing.Point(195, 197);
			this.btnLoadPrices.Name = "btnLoadPrices";
			this.btnLoadPrices.Size = new System.Drawing.Size(75, 41);
			this.btnLoadPrices.TabIndex = 13;
			this.btnLoadPrices.Text = "Load Prices";
			this.btnLoadPrices.UseVisualStyleBackColor = true;
			this.btnLoadPrices.Click += new System.EventHandler(this.btnLoadPrices_Click);
			// 
			// btnSetDate
			// 
			this.btnSetDate.Location = new System.Drawing.Point(195, 103);
			this.btnSetDate.Name = "btnSetDate";
			this.btnSetDate.Size = new System.Drawing.Size(75, 41);
			this.btnSetDate.TabIndex = 11;
			this.btnSetDate.Text = "Set Date";
			this.btnSetDate.UseVisualStyleBackColor = true;
			this.btnSetDate.Click += new System.EventHandler(this.btnSetDate_Click);
			// 
			// btnChargeCommanded
			// 
			this.btnChargeCommanded.Location = new System.Drawing.Point(104, 197);
			this.btnChargeCommanded.Name = "btnChargeCommanded";
			this.btnChargeCommanded.Size = new System.Drawing.Size(75, 41);
			this.btnChargeCommanded.TabIndex = 10;
			this.btnChargeCommanded.Text = "Cmd Chg End Time?";
			this.btnChargeCommanded.UseVisualStyleBackColor = true;
			this.btnChargeCommanded.Click += new System.EventHandler(this.btnChargeEndCommanded_Click);
			// 
			// btnPrice
			// 
			this.btnPrice.Location = new System.Drawing.Point(104, 56);
			this.btnPrice.Name = "btnPrice";
			this.btnPrice.Size = new System.Drawing.Size(75, 41);
			this.btnPrice.TabIndex = 9;
			this.btnPrice.Text = "Price?";
			this.btnPrice.UseVisualStyleBackColor = true;
			this.btnPrice.Click += new System.EventHandler(this.btnPrice_Click);
			// 
			// btnVin
			// 
			this.btnVin.Location = new System.Drawing.Point(104, 103);
			this.btnVin.Name = "btnVin";
			this.btnVin.Size = new System.Drawing.Size(75, 41);
			this.btnVin.TabIndex = 8;
			this.btnVin.Text = "VIN?";
			this.btnVin.UseVisualStyleBackColor = true;
			this.btnVin.Click += new System.EventHandler(this.btnVin_Click);
			// 
			// btnRate
			// 
			this.btnRate.Location = new System.Drawing.Point(104, 9);
			this.btnRate.Name = "btnRate";
			this.btnRate.Size = new System.Drawing.Size(75, 41);
			this.btnRate.TabIndex = 7;
			this.btnRate.Text = "Rate?";
			this.btnRate.UseVisualStyleBackColor = true;
			this.btnRate.Click += new System.EventHandler(this.btnRate_Click);
			// 
			// btnActualChargeFinishTime
			// 
			this.btnActualChargeFinishTime.Location = new System.Drawing.Point(14, 197);
			this.btnActualChargeFinishTime.Name = "btnActualChargeFinishTime";
			this.btnActualChargeFinishTime.Size = new System.Drawing.Size(75, 41);
			this.btnActualChargeFinishTime.TabIndex = 6;
			this.btnActualChargeFinishTime.Text = "Act Charge Finish Time?";
			this.btnActualChargeFinishTime.UseVisualStyleBackColor = true;
			this.btnActualChargeFinishTime.Click += new System.EventHandler(this.btnActualChargeFinishTime_Click);
			// 
			// btnActualChargeStartTime
			// 
			this.btnActualChargeStartTime.Location = new System.Drawing.Point(14, 150);
			this.btnActualChargeStartTime.Name = "btnActualChargeStartTime";
			this.btnActualChargeStartTime.Size = new System.Drawing.Size(75, 41);
			this.btnActualChargeStartTime.TabIndex = 5;
			this.btnActualChargeStartTime.Text = "Act Charge Start Time?";
			this.btnActualChargeStartTime.UseVisualStyleBackColor = true;
			this.btnActualChargeStartTime.Click += new System.EventHandler(this.btnActualChargeStartTime_Click);
			// 
			// btnDate
			// 
			this.btnDate.Location = new System.Drawing.Point(14, 103);
			this.btnDate.Name = "btnDate";
			this.btnDate.Size = new System.Drawing.Size(75, 41);
			this.btnDate.TabIndex = 4;
			this.btnDate.Text = "Date?";
			this.btnDate.UseVisualStyleBackColor = true;
			this.btnDate.Click += new System.EventHandler(this.btnDate_Click);
			// 
			// btnCommand
			// 
			this.btnCommand.Location = new System.Drawing.Point(195, 12);
			this.btnCommand.Name = "btnCommand";
			this.btnCommand.Size = new System.Drawing.Size(75, 41);
			this.btnCommand.TabIndex = 3;
			this.btnCommand.Text = "Command?";
			this.btnCommand.UseVisualStyleBackColor = true;
			this.btnCommand.Click += new System.EventHandler(this.btnCommand_Click);
			// 
			// btnBattData
			// 
			this.btnBattData.Location = new System.Drawing.Point(14, 9);
			this.btnBattData.Name = "btnBattData";
			this.btnBattData.Size = new System.Drawing.Size(75, 41);
			this.btnBattData.TabIndex = 2;
			this.btnBattData.Text = "Batt Data?";
			this.btnBattData.UseVisualStyleBackColor = true;
			this.btnBattData.Click += new System.EventHandler(this.btnBattData_Click);
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.btnClosePort);
			this.panel1.Controls.Add(this.btnOpenPort);
			this.panel1.Location = new System.Drawing.Point(15, 30);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(100, 117);
			this.panel1.TabIndex = 11;
			// 
			// btnClosePort
			// 
			this.btnClosePort.Location = new System.Drawing.Point(12, 59);
			this.btnClosePort.Name = "btnClosePort";
			this.btnClosePort.Size = new System.Drawing.Size(75, 41);
			this.btnClosePort.TabIndex = 2;
			this.btnClosePort.Text = "Close Port";
			this.btnClosePort.UseVisualStyleBackColor = true;
			this.btnClosePort.Click += new System.EventHandler(this.btnClosePort_Click);
			// 
			// btnOpenPort
			// 
			this.btnOpenPort.Location = new System.Drawing.Point(12, 12);
			this.btnOpenPort.Name = "btnOpenPort";
			this.btnOpenPort.Size = new System.Drawing.Size(75, 41);
			this.btnOpenPort.TabIndex = 1;
			this.btnOpenPort.Text = "Open Port";
			this.btnOpenPort.UseVisualStyleBackColor = true;
			this.btnOpenPort.Click += new System.EventHandler(this.btnOpenPort_Click);
			// 
			// txtPortStatus
			// 
			this.txtPortStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.txtPortStatus.Location = new System.Drawing.Point(498, 30);
			this.txtPortStatus.Multiline = true;
			this.txtPortStatus.Name = "txtPortStatus";
			this.txtPortStatus.Size = new System.Drawing.Size(240, 64);
			this.txtPortStatus.TabIndex = 10;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(413, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(62, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Port Status:";
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1264, 882);
			this.Controls.Add(this.tabControl1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmMain";
			this.Text = "PHEV_01";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
			this.tabControl1.ResumeLayout(false);
			this.tabFrequency.ResumeLayout(false);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tabOptions.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.tabTest2.ResumeLayout(false);
			this.tabTest2.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabTest2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtPortStatus;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnClosePort;
		private System.Windows.Forms.Button btnOpenPort;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button btnRate;
		private System.Windows.Forms.Button btnActualChargeFinishTime;
		private System.Windows.Forms.Button btnActualChargeStartTime;
		private System.Windows.Forms.Button btnDate;
		private System.Windows.Forms.Button btnCommand;
		private System.Windows.Forms.Button btnBattData;
		private System.Windows.Forms.Button btnChargeCommanded;
		private System.Windows.Forms.Button btnPrice;
		private System.Windows.Forms.Button btnVin;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtRcxData;
		private System.Windows.Forms.Button btnSetDate;
		private System.Windows.Forms.Button btnLoadPrices;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RadioButton rbPriceProfile4;
		private System.Windows.Forms.RadioButton rbPriceProfile3;
		private System.Windows.Forms.RadioButton rbPriceProfile2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.RadioButton rbPriceProfile1;
		private System.Windows.Forms.Button btnResetSoc;
		private System.Windows.Forms.Button btnCustomCmd;
		private System.Windows.Forms.TextBox txtCustomCmd;
		private System.Windows.Forms.TabPage tabOptions;
		private System.Windows.Forms.Button btnStateRequest;
		private System.Windows.Forms.TabPage tabFrequency;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Label lblLogStatus;
		private System.Windows.Forms.Button btnDebugLogControl;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Label lblPauseStatus;
		private System.Windows.Forms.Button btnPauseControl;
		private System.Windows.Forms.Button btnChargeData;
		private System.Windows.Forms.Button btnEnableRefresh;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private ZedGraph.ZedGraphControl grphFreqChart;
		private ZedGraph.ZedGraphControl grphPwrChart;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Button btnResetPlots;
	}
}

