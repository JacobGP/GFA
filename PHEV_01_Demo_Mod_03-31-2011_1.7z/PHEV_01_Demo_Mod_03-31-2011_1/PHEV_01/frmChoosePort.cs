﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 2010, Battelle Memorial Institute
// Created 06/17/2010
//
// Last modified 06/17/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PHEV_01
{
	public partial class frmChoosePort : Form
	{
		//*********************************************************************************************************
		// Com port selection form
		//**********************************************************************************************************

		#region "Constants"
		#endregion

		#region "Class variables"
			string[] m_PortList;
			string m_SelectedPort = "none";
		#endregion

		#region "Delegates"
		#endregion

		#region "Events"
		#endregion

		#region "Properties"
//			public string[] PortList {	set { m_PortList = value; } }

			public string SelectedPort { get { return m_SelectedPort; } }
		#endregion

		#region "Constructors"
			public frmChoosePort(string[] portList)
			{
				InitializeComponent();

				m_PortList = portList;
				InitPortList(m_PortList);
			}
		#endregion

		#region "Methods"
			private void InitPortList(string[] portList)
			{
				if (portList.Length < 1)
				{
					MessageBox.Show("No ports to select");
					btnOK.Enabled = false;
					return;
				}

				foreach (string currPort in portList)
				{
					ListViewItem newItem = new ListViewItem(currPort);
					newItem.ImageIndex = 0;
					lvPortList.Items.Add(newItem);
				}
			}	// End sub
		#endregion

		#region "Event handlers"
			private void btnOK_Click(object sender, EventArgs e)
			{
				if (lvPortList.SelectedItems.Count != 1)
				{
					MessageBox.Show("One port must be selected");
					return;
				}

				m_SelectedPort = lvPortList.SelectedItems[0].Text;
				this.Hide();
				this.DialogResult = System.Windows.Forms.DialogResult.OK;
			}	// End sub

			private void btnCancel_Click(object sender, EventArgs e)
			{
				m_SelectedPort = "none";
				this.Hide();
				this.DialogResult = DialogResult.Cancel;
			}	// End sub
		#endregion
	}	// End class
}	// End namespace
