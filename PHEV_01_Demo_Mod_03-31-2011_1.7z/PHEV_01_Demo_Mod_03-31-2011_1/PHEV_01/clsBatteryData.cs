﻿
//*********************************************************************************************************
// Written by Dave Clark for the US Department of Energy 
// Pacific Northwest National Laboratory, Richland, WA
// Copyright 09/30/2010, Battelle Memorial Institute
//
//
// Last modified 09/30/2010
//*********************************************************************************************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHEV_01
{
	public class clsBatteryData
	{
		//*********************************************************************************************************
		// Holds batttery data from "B=" statement
		//**********************************************************************************************************

		#region "Properties"
			public int SOC { get; set; }

			public double Volts { get; set; }

			public double Amps { get; set; }

			public double Capacity { get; set; }

			public double Watts { get; set; }
		#endregion
	}	// End class
}	// End namespace
