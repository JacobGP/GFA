﻿namespace PHEV_01
{
	partial class frmLogWindow
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lvLogList = new System.Windows.Forms.ListView();
			this.colhdrId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colhdrDirection = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.colhdrDesc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.SuspendLayout();
			// 
			// lvLogList
			// 
			this.lvLogList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
							| System.Windows.Forms.AnchorStyles.Left)
							| System.Windows.Forms.AnchorStyles.Right)));
			this.lvLogList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colhdrId,
            this.colhdrDirection,
            this.colhdrDesc});
			this.lvLogList.GridLines = true;
			this.lvLogList.Location = new System.Drawing.Point(12, 12);
			this.lvLogList.Name = "lvLogList";
			this.lvLogList.Size = new System.Drawing.Size(519, 304);
			this.lvLogList.TabIndex = 0;
			this.lvLogList.UseCompatibleStateImageBehavior = false;
			this.lvLogList.View = System.Windows.Forms.View.Details;
			this.lvLogList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lvLogList_ColumnClick);
			// 
			// colhdrId
			// 
			this.colhdrId.Text = "ID";
			this.colhdrId.Width = 35;
			// 
			// colhdrDirection
			// 
			this.colhdrDirection.Text = "S/R";
			this.colhdrDirection.Width = 45;
			// 
			// colhdrDesc
			// 
			this.colhdrDesc.Text = "Desc";
			this.colhdrDesc.Width = 430;
			// 
			// frmLogWindow
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(543, 338);
			this.Controls.Add(this.lvLogList);
			this.Name = "frmLogWindow";
			this.Text = "Message Log";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmLogWindow_FormClosing);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ListView lvLogList;
		private System.Windows.Forms.ColumnHeader colhdrId;
		private System.Windows.Forms.ColumnHeader colhdrDirection;
		private System.Windows.Forms.ColumnHeader colhdrDesc;
	}
}