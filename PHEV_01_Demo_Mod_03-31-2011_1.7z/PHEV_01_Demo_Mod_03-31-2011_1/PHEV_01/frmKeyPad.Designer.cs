﻿namespace PHEV_01
{
	partial class frmKeyPad
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.lblValue = new System.Windows.Forms.Label();
			this.lblKey7 = new System.Windows.Forms.Label();
			this.lblKey8 = new System.Windows.Forms.Label();
			this.lblKey9 = new System.Windows.Forms.Label();
			this.lblKey4 = new System.Windows.Forms.Label();
			this.lblKey5 = new System.Windows.Forms.Label();
			this.lblKey6 = new System.Windows.Forms.Label();
			this.lblKey1 = new System.Windows.Forms.Label();
			this.lblKey2 = new System.Windows.Forms.Label();
			this.lblKey3 = new System.Windows.Forms.Label();
			this.lblKeyBksp = new System.Windows.Forms.Label();
			this.lblKey0 = new System.Windows.Forms.Label();
			this.LblKeyClr = new System.Windows.Forms.Label();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 3;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.Controls.Add(this.LblKeyClr, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.lblKey0, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.lblKeyBksp, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.lblKey3, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.lblKey2, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.lblKey1, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.lblKey6, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.lblKey5, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.lblKey4, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.lblKey9, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblKey8, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.lblKey7, 0, 0);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 56);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 4;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(291, 231);
			this.tableLayoutPanel1.TabIndex = 0;
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(12, 303);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(66, 23);
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// btnCancel
			// 
			this.btnCancel.Location = new System.Drawing.Point(214, 303);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(66, 23);
			this.btnCancel.TabIndex = 4;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// lblValue
			// 
			this.lblValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblValue.Location = new System.Drawing.Point(12, 9);
			this.lblValue.Name = "lblValue";
			this.lblValue.Size = new System.Drawing.Size(268, 30);
			this.lblValue.TabIndex = 6;
			this.lblValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblKey7
			// 
			this.lblKey7.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey7.Location = new System.Drawing.Point(11, 3);
			this.lblKey7.Name = "lblKey7";
			this.lblKey7.Size = new System.Drawing.Size(75, 50);
			this.lblKey7.TabIndex = 0;
			this.lblKey7.Text = "7";
			this.lblKey7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey8
			// 
			this.lblKey8.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey8.Location = new System.Drawing.Point(108, 3);
			this.lblKey8.Name = "lblKey8";
			this.lblKey8.Size = new System.Drawing.Size(75, 50);
			this.lblKey8.TabIndex = 1;
			this.lblKey8.Text = "8";
			this.lblKey8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey9
			// 
			this.lblKey9.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey9.Location = new System.Drawing.Point(205, 3);
			this.lblKey9.Name = "lblKey9";
			this.lblKey9.Size = new System.Drawing.Size(75, 50);
			this.lblKey9.TabIndex = 2;
			this.lblKey9.Text = "9";
			this.lblKey9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey4
			// 
			this.lblKey4.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey4.Location = new System.Drawing.Point(11, 60);
			this.lblKey4.Name = "lblKey4";
			this.lblKey4.Size = new System.Drawing.Size(75, 50);
			this.lblKey4.TabIndex = 3;
			this.lblKey4.Text = "4";
			this.lblKey4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey5
			// 
			this.lblKey5.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey5.Location = new System.Drawing.Point(108, 60);
			this.lblKey5.Name = "lblKey5";
			this.lblKey5.Size = new System.Drawing.Size(75, 50);
			this.lblKey5.TabIndex = 4;
			this.lblKey5.Text = "5";
			this.lblKey5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey6
			// 
			this.lblKey6.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey6.Location = new System.Drawing.Point(205, 60);
			this.lblKey6.Name = "lblKey6";
			this.lblKey6.Size = new System.Drawing.Size(75, 50);
			this.lblKey6.TabIndex = 5;
			this.lblKey6.Text = "6";
			this.lblKey6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey1
			// 
			this.lblKey1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey1.Location = new System.Drawing.Point(11, 117);
			this.lblKey1.Name = "lblKey1";
			this.lblKey1.Size = new System.Drawing.Size(75, 50);
			this.lblKey1.TabIndex = 6;
			this.lblKey1.Text = "1";
			this.lblKey1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey2
			// 
			this.lblKey2.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey2.Location = new System.Drawing.Point(108, 117);
			this.lblKey2.Name = "lblKey2";
			this.lblKey2.Size = new System.Drawing.Size(75, 50);
			this.lblKey2.TabIndex = 7;
			this.lblKey2.Text = "2";
			this.lblKey2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey3
			// 
			this.lblKey3.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey3.Location = new System.Drawing.Point(205, 117);
			this.lblKey3.Name = "lblKey3";
			this.lblKey3.Size = new System.Drawing.Size(75, 50);
			this.lblKey3.TabIndex = 8;
			this.lblKey3.Text = "3";
			this.lblKey3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKeyBksp
			// 
			this.lblKeyBksp.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKeyBksp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKeyBksp.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKeyBksp.Location = new System.Drawing.Point(205, 176);
			this.lblKeyBksp.Name = "lblKeyBksp";
			this.lblKeyBksp.Size = new System.Drawing.Size(75, 50);
			this.lblKeyBksp.TabIndex = 9;
			this.lblKeyBksp.Text = "Bksp";
			this.lblKeyBksp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblKey0
			// 
			this.lblKey0.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.lblKey0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblKey0.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblKey0.Location = new System.Drawing.Point(108, 176);
			this.lblKey0.Name = "lblKey0";
			this.lblKey0.Size = new System.Drawing.Size(75, 50);
			this.lblKey0.TabIndex = 10;
			this.lblKey0.Text = "0";
			this.lblKey0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LblKeyClr
			// 
			this.LblKeyClr.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.LblKeyClr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.LblKeyClr.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LblKeyClr.Location = new System.Drawing.Point(11, 176);
			this.LblKeyClr.Name = "LblKeyClr";
			this.LblKeyClr.Size = new System.Drawing.Size(75, 50);
			this.LblKeyClr.TabIndex = 11;
			this.LblKeyClr.Text = "Clr";
			this.LblKeyClr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmKeyPad
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 341);
			this.ControlBox = false;
			this.Controls.Add(this.lblValue);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmKeyPad";
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Label lblValue;
		private System.Windows.Forms.Label lblKey3;
		private System.Windows.Forms.Label lblKey2;
		private System.Windows.Forms.Label lblKey1;
		private System.Windows.Forms.Label lblKey6;
		private System.Windows.Forms.Label lblKey5;
		private System.Windows.Forms.Label lblKey4;
		private System.Windows.Forms.Label lblKey9;
		private System.Windows.Forms.Label lblKey8;
		private System.Windows.Forms.Label lblKey7;
		private System.Windows.Forms.Label LblKeyClr;
		private System.Windows.Forms.Label lblKey0;
		private System.Windows.Forms.Label lblKeyBksp;
	}
}