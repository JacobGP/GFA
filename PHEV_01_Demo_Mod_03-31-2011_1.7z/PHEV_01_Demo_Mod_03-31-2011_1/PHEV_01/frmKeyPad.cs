﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PHEV_01
{
	public partial class frmKeyPad : Form
	{
		public frmKeyPad()
		{
			InitializeComponent();
		}
	}
}
